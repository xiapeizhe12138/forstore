# Copyright (c) OpenMMLab. All rights reserved.
import argparse
import copy
import os
import os.path as osp
import time
import sys
sys.path.append('.')
import mmcv
import torch

from mmcv import Config
from mmcv.runner import init_dist

from mmedit import __version__
from mmedit.apis import set_random_seed, train_model
from mmedit.core.distributed_wrapper import DistributedDataParallelWrapper
from mmedit.datasets import build_dataset
from mmedit.models import build_model
from mmedit.utils import collect_env, get_root_logger

import socket
#in_fbcode = True if 'fb' in socket.gethostname() or 'facebook' in socket.gethostname() else False
in_fbcode = False
# if in_fbcode:
    # from iopath.common.file_io import PathManager
    # from iopath.fb.manifold import ManifoldPathHandler
    # pathmgr = PathManager()
    # pathmgr.register_handler(ManifoldPathHandler())


def parse_args():
    parser = argparse.ArgumentParser(description="Train an editor")
    parser.add_argument("config", help="train config file path")
    parser.add_argument("--work-dir", help="the dir to save logs and models")
    parser.add_argument("--resume-from", help="the checkpoint file to resume from")
    parser.add_argument(
        "--no-validate",
        action="store_true",
        help="whether not to evaluate the checkpoint during training",
    )
    parser.add_argument(
        "--gpus",
        type=int,
        default=1,
        help="number of gpus to use " "(only applicable to non-distributed training)",
    )
    parser.add_argument("--seed", type=int, default=None, help="random seed")
    parser.add_argument(
        "--deterministic",
        action="store_true",
        help="whether to set deterministic options for CUDNN backend.",
    )
    parser.add_argument(
        "--launcher",
        choices=["none", "pytorch", "slurm", "mpi"],
        default="none",
        help="job launcher",
    )
    parser.add_argument("--local_rank", type=int, default=0)
    parser.add_argument(
        "--autoscale-lr",
        action="store_true",
        help="automatically scale lr with the number of gpus",
    )
    args = parser.parse_args()
    if "LOCAL_RANK" not in os.environ:
        os.environ["LOCAL_RANK"] = str(args.local_rank)

    return args


def main():
    args = parse_args()
    # os.environ["TORCH_DISTRIBUTED_DEBUG"] = "DETAIL" # for DDP debugging

    if "manifold" in args.config or not in_fbcode:
        print(f"load config files from manifold or regular disk {args.config}")
    else:
        args.config = osp.join(osp.dirname(osp.dirname(__file__)), args.config)
        print(f"load config files from fbcode with abstract path {args.config}")
    cfg = Config.fromfile(args.config)
    # set cudnn_benchmark
    if cfg.get("cudnn_benchmark", False):
        torch.backends.cudnn.benchmark = True
    # update configs according to CLI args
    if args.work_dir is not None:
        cfg.work_dir = args.work_dir
    if args.resume_from is not None:
        cfg.resume_from = args.resume_from
    else:
        # automatic resume
        resume_from = cfg.work_dir + "/latest.pth"
        # if in_fbcode:
            # if pathmgr.exists(resume_from):
                # cfg.resume_from = resume_from
                # args.resume_from = resume_from
                # print(f"automatic resuming from {resume_from}")
        # else:
        if os.path.exists(resume_from):
            cfg.resume_from = resume_from
            args.resume_from = resume_from
            print(f"automatic resuming from {resume_from}")

    cfg.gpus = args.gpus

    if args.autoscale_lr:
        # apply the linear scaling rule (https://arxiv.org/abs/1706.02677)
        cfg.optimizer["lr"] = cfg.optimizer["lr"] * cfg.gpus / 8

    # init distributed env first, since logger depends on the dist info.
    if args.launcher == "none":
        distributed = False
    else:
        distributed = True
        init_dist(args.launcher, **cfg.dist_params)

    # create work_dir
    mmcv.mkdir_or_exist(osp.abspath(cfg.work_dir))
    # if in_fbcode:
        # pathmgr.mkdirs(cfg.work_dir)
    # init the logger before other steps
    timestamp = time.strftime("%Y%m%d_%H%M%S", time.localtime())
    log_file = osp.join(cfg.work_dir, f"{timestamp}.log")
    logger = get_root_logger(log_file=log_file, log_level=cfg.log_level)

    # log env info
    env_info_dict = collect_env.collect_env()
    env_info = "\n".join([f"{k}: {v}" for k, v in env_info_dict.items()])
    dash_line = "-" * 60 + "\n"
    logger.info("Environment info:\n" + dash_line + env_info + "\n" + dash_line)

    # log some basic info
    logger.info("Distributed training: {}".format(distributed))
    logger.info("mmedit Version: {}".format(__version__))
    logger.info("Config:\n{}".format(cfg.text))

    # set random seeds
    if args.seed is not None:
        logger.info(
            "Set random seed to {}, deterministic: {}".format(
                args.seed, args.deterministic
            )
        )
        set_random_seed(args.seed, deterministic=args.deterministic)
    cfg.seed = args.seed

    model = build_model(cfg.model, train_cfg=cfg.train_cfg, test_cfg=cfg.test_cfg)

    datasets = [build_dataset(cfg.data.train)]
    if len(cfg.workflow) == 2:
        val_dataset = copy.deepcopy(cfg.data.val)
        val_dataset.pipeline = cfg.data.train.pipeline
        datasets.append(build_dataset(val_dataset))
    if cfg.checkpoint_config is not None:
        # save version, config file content and class names in
        # checkpoints as meta data
        cfg.checkpoint_config.meta = dict(
            mmedit_version=__version__,
            config=cfg.text,
        )

    # meta information
    meta = dict()
    if cfg.get("exp_name", None) is None:
        cfg["exp_name"] = osp.splitext(osp.basename(cfg.work_dir))[0]
    meta["exp_name"] = cfg.exp_name
    meta["mmedit Version"] = __version__
    meta["seed"] = args.seed
    meta["env_info"] = env_info

    mmedit_to_ddp = DistributedDataParallelWrapper.to_ddp
    def to_ddp(self, *args, **kwargs):
        """A wrapper for DistributedDataParallelWrapper.to_ddp() in mmediting/core/distributed_wrapper.py
        to support use_static_graph."""
        mmedit_to_ddp(self, *args, **kwargs)
        if cfg.get("use_static_graph", False):
            print("-------using static graph for generator in DDP")
            self.module._modules["generator"]._set_static_graph()
    DistributedDataParallelWrapper.to_ddp = to_ddp
    # export CUDA_DEVICE_ORDER="PCI_BUS_ID"

    # add an attribute for visualization convenience
    train_model(
        model,
        datasets,
        cfg,
        distributed=distributed,
        validate=(not args.no_validate),
        timestamp=timestamp,
        meta=meta,
    )


if __name__ == "__main__":
    main()
