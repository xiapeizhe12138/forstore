import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import repeat
import math
import numpy as np
import time
import pdb
import models
from models import register
from utils import make_coord

from models.ss2d import SS2D
from models.windowss2d import windowSS2D

@register('m3-middle-linear')
class MgobalSRNet(nn.Module):
    """
    The subclasses should define `generator` with `encoder` and `imnet`,
        and overwrite the function `gen_feature`.
    If `encoder` does not contain `mid_channels`, `__init__` should be
        overwrite.

    Args:
        encoder (dict): Config for the generator.
        imnet (dict): Config for the imnet.
        feat_unfold (bool): Whether to use feature unfold. Default: True.
        eval_bsize (int): Size of batched predict. Default: None.
    """

    def __init__(self,
                 encoder,
                 SSM,
                 LSSM,
                 imnet1,
                 imnet2,
                 expend=None,
                 featcat=False,
                 cropstep=128,
                 mincrop=64,
                 local_size=2,
                 feat_unfold=True,
                 # eval_bsize=None,
                 non_local=True,
                 # softmax_scale=1,
                #  unfold_channel=3,
                 ):
        super().__init__()

        self.feat_unfold = feat_unfold
        # self.eval_bsize = eval_bsize
        self.local_size = local_size
        self.non_local = non_local
        self.featcat = featcat
        self.expend = expend
        # self.multi_scale = multi_scale
        # self.softmax_scale = softmax_scale
        self.cropstep = cropstep
        self.mincrop = mincrop
        # self.unfold_channel = unfold_channel
        
        self.encoder = models.make(encoder, args={'no_upsampling': True})
        imnet_dim = self.encoder.out_dim
        
        if self.expend :
            self.beforeup = nn.Conv2d(imnet_dim, self.expend, 1, stride=1, padding=0)
            imnet_dim = self.expend
            assert Fasle, "not finished"
        # self.upchannel = imnet_dim * self.unfold_channel
        
        if self.feat_unfold:
            LSSM['args']['d_model'] = imnet_dim
            imnet1['args']['in_dim'] = LSSM['args']['out_channel_multi']*imnet_dim
        else:
            imnet1['args']['in_dim'] = imnet_dim
        
        if self.non_local:
            imnet1['args']['in_dim'] += imnet_dim
        
        if self.featcat:
            imnet1['args']['in_dim'] += imnet_dim

        imnet1['args']['in_dim'] += 4
        SSM['args']['in_dim'] = imnet1['args']['out_dim']
        SSM['args']['out_channel'] = int(SSM['args']['in_dim']/4)
        imnet2['args']['in_dim'] = SSM['args']['out_channel']*self.local_size*self.local_size

        self.global_SS2D = SS2D(d_model=SSM['args']['in_dim'],
                    out_channel=SSM['args']['out_channel'],
                    d_state=SSM['args']['d_state'],
                    d_conv=SSM['args']['d_conv'],
                    expand=SSM['args']['expand']) 
        self.imnet1 = models.make(imnet1) 
        self.imnet2 = models.make(imnet2) 

        if self.non_local:
            self.non_local_ssm = SS2D(d_model=imnet_dim,
                            out_channel=imnet_dim)    

        self.localssm = windowSS2D(d_model=LSSM['args']['d_model'],
                            out_channel=LSSM['args']['out_channel_multi']*imnet_dim,
                            sumscan=LSSM['args']['sumscan'],
                            windowsize=LSSM['args']['windowsize'],
                            positionlinear=LSSM['args']['positionlinear'] if 'positionlinear' in LSSM['args'].keys() else False,
                            expand=LSSM['args']['expand'])
            
        self.countgenfeat = False
        self.feat_coord = None

    def gen_feat(self, inp):
        self.inp = inp
        feat = self.encoder(inp)
        '''
        if hasattr(self.encoder, 'embed_dim'):
            # SwinIR
            feat = self.encoder.check_image_size(inp)
            feat = self.encoder.conv_first(feat)
            feat = self.encoder.conv_after_body(self.encoder.forward_features(feat)) + feat
        else:
            feat = self.encoder(inp)
        '''

        if self.training or self.feat_coord is None or self.feat_coord.shape[-2] != feat.shape[-2] \
                or self.feat_coord.shape[-1] != feat.shape[-1]:
            self.feat_coord = make_coord(feat.shape[-2:], flatten=False).cuda() \
                .permute(2, 0, 1) \
                .unsqueeze(0).expand(feat.shape[0], 2, *feat.shape[-2:])

        B, C, H, W = feat.shape
        if self.non_local:
            crop_h, crop_w = 48, 48
            if H * W > crop_h * crop_w:
            # if False:
                # Fixme: generate cross attention by image patches
                self.non_local_feat_v = torch.zeros(B, C, H, W).cuda()
                for i in range(H // crop_h):
                    for j in range(W // crop_w):
                        i1, i2 = i * crop_h, ((i + 1) * crop_h if i < H // crop_h - 1 else H)
                        j1, j2 = j * crop_w, ((j + 1) * crop_w if j < W // crop_w - 1 else W)

                        padding = 3 // 2
                        pad_i1, pad_i2 = (padding if i1 - padding >= 0 else 0), (
                            padding if i2 + padding <= H else 0)
                        pad_j1, pad_j2 = (padding if j1 - padding >= 0 else 0), (
                            padding if j2 + padding <= W else 0)

                        crop_feat = feat[:, :, i1 - pad_i1:i2 + pad_i2, j1 - pad_j1:j2 + pad_j2]
                        crop_non_local_feat = self.non_local_ssm(crop_feat.permute(0, 2, 3, 1).contiguous(), outype='chw')
                        self.non_local_feat_v[:, :, i1:i2, j1:j2] = crop_non_local_feat[:, :,
                                                               pad_i1:crop_non_local_feat.shape[-2] - pad_i2,
                                                               pad_j1:crop_non_local_feat.shape[-1] - pad_j2]
            else:
                self.non_local_feat_v = self.non_local_ssm(feat.permute(0, 2, 3, 1).contiguous(), outype='chw')  # [16, 64, 48, 48]

        self.feats = [feat]
        return self.feats

    def query_rgb(self, coord, scale=None):
        """Query RGB value of GT.

        Copyright (c) 2020, Yinbo Chen, under BSD 3-Clause License.

        Args:
            feature (Tensor): encoded feature.
            coord (Tensor): coord tensor, shape (BHW, 2).

        Returns:
            result (Tensor): (part of) output.
        """

        res = []
        # print(features[1])  error      features is just a tensor in dict  
        for feature in self.feats:
            
            bs, h, w, _ = coord.shape
            Br, Hr, Wr, Cr = scale.shape
            assert (h==Hr and w==Wr) , "size of coord and cell not match"

            # if self.expend is not None:
                # feature = self.beforeup(feature)
            
            if self.feat_unfold:
                # featureC = feature.permute(0, 2, 3, 1).contiguous()
                feat = self.localssm(feature.permute(0, 2, 3, 1).contiguous(), outype='chw')
                if self.non_local:
                    # non_local_feat = self.non_local_ssm(featureC, outype='chw')#mamba
                    feat = torch.cat([feat, self.non_local_feat_v], dim=1)
                    # del non_local_feat
                # del featureC
                if self.featcat:
                    feat = torch.cat([feature, feat], dim=1)
            else:
                feat = feature
            # print(f"\n\n{feat.shape}\n\n")
            B, C, H, W = feat.shape
            #low B, C, H, W
            #high B, C, h, w

            feat_coord = make_coord(feature.shape[-2:], flatten=False).permute(2, 0, 1) \
                            .unsqueeze(0).expand(B, 2, *feature.shape[-2:])                   #B,C,h,w
            feat_coord = feat_coord.to(coord)
            del feature
            
            if self.local_size == 1:
                v_lst = [(0, 0)]
            else:
                v_lst = [(i,j) for i in range(-1, 2, 4-self.local_size) for j in range(-1, 2, 4-self.local_size)]
            eps_shift = 1e-6
            
            preds = []
            areas = []
            
            for v in v_lst:
                vx, vy = v[0], v[1]
                # project to LR field
                tx = ((H - 1) / (1 - scale[:,0,0,0])).view(B,  1)
                ty = ((W - 1) / (1 - scale[:,0,0,1])).view(B,  1)
                rx = (2*abs(vx) -1) / tx if vx != 0 else 0
                ry = (2*abs(vy) -1) / ty if vy != 0 else 0
                
                coord_ = coord.clone().view(bs, h*w, -1)
                if vx != 0:
                    coord_[:, :, 0] += vx /abs(vx) * rx + eps_shift
                if vy != 0:
                    coord_[:, :, 1] += vy /abs(vy) * ry + eps_shift
                coord_ = coord_.clamp_(-1 + 1e-6, 1 - 1e-6).view(bs, h, w, 2)
                
                # value
                upfeat = F.grid_sample(feat, coord_.flip(-1), mode='nearest',                 #upsize feature
                    align_corners=False).permute(0, 2, 3, 1).contiguous()                     #B,C,h,w

                #Interpolate feat_coord to HR resolution
                coord_k = F.grid_sample(feat_coord, coord_.flip(-1),                          #upsize feature coord
                    mode='nearest', align_corners=False).permute(0, 2, 3, 1).contiguous()     #B,C,h,w

                rel_coord = coord - coord_k                                                   #B,C,h,w
                rel_coord[:, :, :, 0] *= (H/2)                                    #relative coord information
                rel_coord[:, :, :, 1] *= (W/2)
                del coord_;del coord_k

                scale_ = scale.clone()                                                        #B,C,h,w
                scale_[:, :, :, 0] *= (H/2)                                       #size information
                scale_[:, :, :, 1] *= (W/2)

                inp = torch.cat([upfeat, rel_coord, scale_], dim=-1).contiguous()             #input get
                del scale_;del upfeat;del rel_coord

                inp = self.imnet1(inp)
                pred = self.global_SS2D(inp, outype='hwc')                                           #B,h,w,C
                del inp

                preds.append(pred)
                del pred

            ret = torch.cat(preds, dim=-1).view(bs, h*w, -1)
            
            ret = self.imnet2(ret).view(bs, h, w, -1)
            res.append(ret)
            del ret
    
        result = torch.cat(res, dim=-1).permute(0, 3, 1, 2).contiguous()                       #B,C,h,w
        del res
        B, C, H, W=result.shape
        assert (B==bs and C==3) and (H==h and W==w),'wrong output size'
        
        result += F.grid_sample(self.inp, coord.flip(-1), mode='bilinear',
                                padding_mode='border', align_corners=False)#[:, :, 0, :].permute(0, 2, 1)
        return result
    
    def cropdim(self, h):
        #我们希望将step转换成一个起始元素0，结束元素lenth/-1的递增序列，相邻元素之间间隔为crop，最末间隔不低于mincrop的数组
        step = np.arange(0, h, self.cropstep)
        if(h-step[-1] < self.mincrop):
            step[-1] = h
        else:
            step = np.append(step,h)
        return step
    
    def batched_predict(self, x, coord, cell):
        """Batched predict.

        Args:
            x (Tensor): Input tensor.
            coord (Tensor): coord tensor.
            cell (Tensor): cell tensor.

        Returns:
            pred (Tensor): output of model.
        """
        with torch.no_grad():
            # if coord is None and cell is None:
            #     # Evaluate encoder efficiency
            #     feat = self.encoder(x)
            #     return None

            self.gen_feat(x)
            
            # B, H, W, C = coord.shape
            # h = 0
            # preds = []
            # predhs = []
            # while h < H:
            #     w = 0
            #     hr = min(h + bsize, H)
            #     while w < W:
            #         wr = min(w + bsize, W)
            #         predhw = self.query_rgb(coord[:, h: hr, w: wr, :], cell[:, h: hr, w: wr, :])
            #         predhs.append(predhw)
            #         w = wr
            #     predhs = torch.cat(predhs, dim=3)
            #     preds.append(predhs)
            #     predhs = []
            #     h = hr
            # preds = torch.cat(preds, dim=2)
        # return preds
            B, C, h, w = x.shape 
            assert B==1, "batchsize not match"
            Bc, Hc, Wc, _ = coord.shape
            Br, Hr, Wr, _ = cell.shape
            H = round(float(2/cell[0,0,0,0]))
            W = round(float(2/cell[0,0,0,1]))
            assert H==Hc and H==Hr, "inputsize not match"
            assert W==Wc and W==Wr, "inputsize not match"
            hspace = self.cropdim(H)#, crop=120, mincrop=60)
            wspace = self.cropdim(W)#, crop=120, mincrop= 60)
            preds_hcrop = []
            for i in range(len(hspace)-1):
                preds_hwcrop = []
                for j in range(len(wspace)-1):
                    pred = self.query_rgb(coord[:, hspace[i]:hspace[i+1], wspace[j]:wspace[j+1], :].contiguous(),
                                      cell[:, hspace[i]:hspace[i+1], wspace[j]:wspace[j+1], :].contiguous())
                    preds_hwcrop.append(pred)
                pred = torch.cat(preds_hwcrop, dim=3)
                # print(f"preds_hcrop.shape  {pred.shape}")
                preds_hcrop.append(pred)
            pred = torch.cat(preds_hcrop, dim=2)
        return pred
        
    def forward(self, x, coord, cell, bpred=None):
        """Forward function.

        Args:
            x: input tensor.
            coord (Tensor): coordinates tensor.
            cell (Tensor): cell tensor.
            test_mode (bool): Whether in test mode or not. Default: False.

        Returns:
            pred (Tensor): output of model.
        """
        if bpred is not None:
            pred = self.batched_predict(x, coord, cell)
        else:
            self.gen_feat(x)
            pred = self.query_rgb(coord, cell)

        return pred
