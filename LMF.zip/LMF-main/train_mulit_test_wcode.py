"""
Modified from: https://github.com/yinboc/liif
"""

import argparse
import os

import yaml
import torch
import torch.nn as nn
from tqdm import tqdm
from torch.utils.data import DataLoader
from torch.optim.lr_scheduler import MultiStepLR

import datasets
import models
import utils
from test import eval_psnr
from datetime import datetime

def make_data_loader(spec, tag='', name=None):
    if spec is None:
        return None
    
    dataset = datasets.make(spec['dataset'])
    dataset = datasets.make(spec['wrapper'], args={'dataset': dataset})
    
    if tag == 'val' and name is not None:
        log('{} {} dataset: size={}'.format(tag, name, len(dataset)))
    else:
        log('{} dataset: size={}'.format(tag, len(dataset)))
    for k, v in dataset[0].items():
        if 'key' not in k:
            log('  {}: shape={}'.format(k, tuple(v.shape)))

    loader = DataLoader(dataset, batch_size=spec['batch_size'],
        shuffle=(tag == 'train'), num_workers=8, pin_memory=True)
    return loader


def make_data_loaders():
    train_loader = make_data_loader(config.get('train_dataset'), tag='train')
    val_loaders = {}
    for i in range(len(config.get('val_dataset'))):
        name =config['val_dataset'][i]
        val_loader = make_data_loader(config.get(name), tag='val')
        val_loaders[name] = val_loader
    return train_loader, val_loaders


def prepare_training():
    if os.path.exists(config.get('resume')):
        log('load model form {}'.format(config['resume']))
        sv_file = torch.load(config['resume'])
        model = models.make(sv_file['model'], load_sd=True).cuda()
        optimizer = utils.make_optimizer(
            model.parameters(), sv_file['optimizer'], load_sd=True)
        epoch_start = sv_file['epoch'] + 1
        if config.get('multi_step_lr') is None:
            lr_scheduler = None
        else:
            lr_scheduler = MultiStepLR(optimizer, **config['multi_step_lr'])
        for _ in range(epoch_start - 1):
            lr_scheduler.step()
    else:
        model = models.make(config['model']).cuda()
        optimizer = utils.make_optimizer(
            model.parameters(), config['optimizer'])
        epoch_start = 1
        if config.get('multi_step_lr') is None:
            lr_scheduler = None
        else:
            lr_scheduler = MultiStepLR(optimizer, **config['multi_step_lr'])

    log('model: #params={}'.format(utils.compute_num_params(model, text=True)))
    return model, optimizer, epoch_start, lr_scheduler


def train(train_loader, model, optimizer, epoch, dim2, log, log_per_iter, save_name):
    model.train()
    
    loss_fn = nn.L1Loss()
    loss_code = nn.MSELoss()
    
    train_loss = utils.Averager()
    metric_fn = utils.calc_psnr

    data_norm = config['data_norm']
    t = data_norm['inp']
    inp_sub = torch.FloatTensor(t['sub']).view(1, -1, 1, 1).cuda()
    inp_div = torch.FloatTensor(t['div']).view(1, -1, 1, 1).cuda()
    t = data_norm['gt']
    if dim2:
        gt_sub = torch.FloatTensor(t['sub']).view(1, -1, 1, 1).cuda()
        gt_div = torch.FloatTensor(t['div']).view(1, -1, 1, 1).cuda()
    else:
        gt_sub = torch.FloatTensor(t['sub']).view(1, 1, -1).cuda()
        gt_div = torch.FloatTensor(t['div']).view(1, 1, -1).cuda()
    
    num_dataset = 400000 #compression
    iter_per_epoch = int(num_dataset / config.get('train_dataset')['batch_size'] \
                        * config.get('train_dataset')['dataset']['args']['repeat'])
    iteration = 0
    for batch in tqdm(train_loader, leave=False, desc='train', disable=True):
        for k, v in batch.items():
            if 'key' not in k:
                batch[k] = v.cuda()

        inp = (batch['inp'] - inp_sub) / inp_div
        pred, predcode = model(inp, batch['coord'], batch['cell'], returncode=True)

        gt = (batch['gt'] - gt_sub) / gt_div
        loss = loss_fn(pred, gt)
        losscode = loss_code(predcode, batch['infocode'])
        # psnr = metric_fn(pred, gt)
        
        # tensorboard
        writer.add_scalars('loss', {'Img_loss': loss.item(), 'Code_loss': losscode.item()}, (epoch-1)*iter_per_epoch + iteration)
        # writer.add_scalars('loss_img', {'train': loss.item()}, 'loss_code', {'train': losscode.item()}, (epoch-1)*iter_per_epoch + iteration)
        # writer.add_scalars('psnr', {'train': psnr}, (epoch-1)*iter_per_epoch + iteration)
        iteration += 1
        
        if (iteration+(epoch-1)*iter_per_epoch) % log_per_iter == 0 :
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            log(f"{formatted_time} Model:{save_name} Epoch:{epoch} Iter:{iteration+(epoch-1)*iter_per_epoch} Loss_img:{loss:.4f} Loss_code:{losscode:.4f}")
        
        loss = loss + losscode
        train_loss.add(loss.item())

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        pred = None; loss = None
        
    return train_loss.item()


def main(config_, save_path, save_name, testmod=False, save_folder=None):
    print('start main')
    global config, log, writer
    config = config_
    log, writer = utils.set_save_path(save_path, remove=False)
    with open(os.path.join(save_path, 'config.yaml'), 'w') as f:
        yaml.dump(config, f, sort_keys=False)
    
    print('setting models and trainners')
    model, optimizer, epoch_start, lr_scheduler = prepare_training()
    
    print('making data loaders')
    train_loader, val_loaders = make_data_loaders()
    if config.get('data_norm') is None:
        config['data_norm'] = {
            'inp': {'sub': [0], 'div': [1]},
            'gt': {'sub': [0], 'div': [1]}
        }
    

    n_gpus = len(os.environ['CUDA_VISIBLE_DEVICES'].split(','))
    if n_gpus > 1:
        model = nn.parallel.DataParallel(model)

    epoch_max = config['epoch_max']
    epoch_val = config.get('epoch_val')
    epoch_valstart = config.get('epoch_valstart', 0)
    epoch_valarray = config.get('epoch_valarray', [])
    if epoch_valstart is None:
        epoch_valstart = 0
    epoch_save = config.get('epoch_save')
    log_per_iter = config.get('log_per_iter')
    dim2 = config.get('eval_dim2')
    max_val_v = -1e18

    timer = utils.Timer()
    print('start train')
    print(f"total epoch {epoch_max}")
    if n_gpus > 1 and (config.get('eval_bsize') is not None):
        model_ = model.module
    else:
        model_ = model
    if testmod:
        for key, val_loader in val_loaders.items():
            val_res = eval_psnr(val_loader, model_,
                                data_norm=config['data_norm'],
                                eval_type=config.get('eval_type'),
                                eval_bsize=config.get('eval_bsize'),
                                overlap=config.get('overlap'),
                                save_folder=save_folder + "/" + key, 
                                dim2=dim2)

            log('{} val: psnr={:.4f}'.format(key, val_res))

    else:
        for epoch in range(epoch_start, epoch_max + 1):
            
            t_epoch_start = timer.t()

            writer.add_scalar('lr', optimizer.param_groups[0]['lr'], epoch)

            train_loss = train(train_loader, model, optimizer, epoch, dim2, log, log_per_iter, save_name)
            log_info = ['epoch {}/{}'.format(epoch, epoch_max)]
            if lr_scheduler is not None:
                lr_scheduler.step()

            log_info.append(' train: loss={:.4f}'.format(train_loss))

            if n_gpus > 1:
                model_ = model.module
            else:
                model_ = model
            model_spec = config['model']
            model_spec['sd'] = model_.state_dict()
            optimizer_spec = config['optimizer']
            optimizer_spec['sd'] = optimizer.state_dict()
            sv_file = {
                'model': model_spec,
                'optimizer': optimizer_spec,
                'epoch': epoch
            }

            torch.save(sv_file, os.path.join(save_path, 'epoch-last.pth'))

            if (epoch_save is not None) and (epoch % epoch_save == 0):
                torch.save(sv_file,
                    os.path.join(save_path, 'epoch-{}.pth'.format(epoch)))

            valfollow = (((epoch - epoch_valstart) % epoch_val == 0) and (epoch >= epoch_valstart))
            vallist = (epoch in epoch_valarray)
            if (epoch_val is not None) and (valfollow or vallist):
                if n_gpus > 1 and (config.get('eval_bsize') is not None):
                    model_ = model.module
                else:
                    model_ = model
                for key, val_loader in val_loaders.items():
                    val_res = eval_psnr(val_loader, model_,
                                        data_norm=config['data_norm'],
                                        eval_type=config.get('eval_type'),
                                        eval_bsize=config.get('eval_bsize'),
                                        overlap=config.get('overlap'),
                                        dim2=dim2)

                    log_info.append('{} val: psnr={:.4f}'.format(key, val_res))
    #             writer.add_scalars('psnr', {'val': val_res}, epoch)
                if val_res > max_val_v:
                    max_val_v = val_res
                    torch.save(sv_file, os.path.join(save_path, 'epoch-best.pth'))

            t = timer.t()
            prog = (epoch - epoch_start + 1) / (epoch_max - epoch_start + 1)
            t_epoch = utils.time_text(t - t_epoch_start)
            t_elapsed, t_all = utils.time_text(t), utils.time_text(t / prog)
            log_info.append('{} {}/{}'.format(t_epoch, t_elapsed, t_all))

            log(', '.join(log_info))
            writer.flush()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--config')
    parser.add_argument('--name', default=None)
    parser.add_argument('--tag', default=None)
    parser.add_argument('--gpu', default='0')
    parser.add_argument('--testmod', default=False)
    parser.add_argument('--save_img', default=False)
    parser.add_argument('--loadmodel', default=None)
    args = parser.parse_args()

    os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu

    with open(args.config, 'r') as f:
        config = yaml.load(f, Loader=yaml.FullLoader)
        print('config loaded.')

    save_name = args.name
    if save_name is None:
        save_name = '_' + args.config.split('/')[-1][:-len('.yaml')]
    if args.tag is not None:
        save_name += '_' + args.tag
    print(config['savepath'])
    save_path = os.path.join(config['savepath'], save_name)
    save_folder = save_path if args.save_img else None
    # testmod = config.get('testmod', False)
    if args.loadmodel is not None:
        config['resume'] = args.loadmodel
    
    main(config, save_path, args.name, testmod=args.testmod, save_folder=save_folder)