import torch.nn as nn
import torch
import models
from models import register


@register('modmlp')
class MODMLP(nn.Module):

    def __init__(self, in_dim, out_dim, hidden_list, scalemlp, codemlp, modlist, use_conv=False):
        super().__init__()
        layers = []
        lastv = in_dim
        for hidden in hidden_list:
            if use_conv:
                layers.append(nn.Conv2d(lastv, hidden, 1))
            else:
                layers.append(nn.Linear(lastv, hidden))
            layers.append(nn.ReLU())
            lastv = hidden
        if use_conv:
            layers.append(nn.Conv2d(lastv, out_dim, 1))
        else:
            layers.append(nn.Linear(lastv, out_dim))
            
        self.modlist = modlist# mod which linear
        mod_outdim = 0
        self.mod_dim = []
        for i in range(len(self.modlist)):
            self.mod_dim.append(mod_outdim)
            mod_outdim += hidden_list[self.modlist[i]-1]
        self.mod_dim.append(mod_outdim)
        
        self.scalemlp = models.make(scalemlp, args={'in_dim': 2, 'out_dim': mod_outdim})#generate mod for scale
        self.codemlp = models.make(codemlp, args={'out_dim': mod_outdim})#generate mod for code
        
        self.layers = nn.Sequential(*layers)

    def mod(self, scale, code):
        Bs, _ = scale.shape
        Bc, _ = code.shape
        assert Bs == Bc, "shape must match"
        self.scale_mod = self.scalemlp(scale).view(Bs, -1)
        self.code_mod = self.codemlp(code).view(Bs, -1)
        
    def forward(self, x):
        # print(x.shape)
        B = x.shape[0]
        C = x.shape[-1]
        shape = x.shape[1:-1]
        x = x.view(B, -1, C)
        # x = self.layers(x.view(-1, x.shape[-1]))
        mod_idx = 0
        
        for idx, module in enumerate(self.layers):
            
            if (idx//2+1) in self.modlist and (idx%2==0):
                assert self.mod_dim[mod_idx+1]-self.mod_dim[mod_idx] == module.out_features, f"mod dim{self.mod_dim[mod_idx+1]-self.mod_dim[mod_idx]} must match linear outdim{module.out_features}"
                scale_mod = (self.scale_mod[:, self.mod_dim[mod_idx]:self.mod_dim[mod_idx+1]]).clone().unsqueeze(-1).expand(-1, module.out_features, module.in_features)
                code_mod = (self.code_mod[:, self.mod_dim[mod_idx]:self.mod_dim[mod_idx+1]]).clone().unsqueeze(-1).expand(-1, module.out_features, module.in_features)
                
                weight = module.weight * scale_mod * code_mod
                # print(x.shape, weight.shape)

                x = torch.einsum("b l c, b d c -> b l d", x, weight) + module.bias
                
                mod_idx += 1
            else:
                x = module(x)
        
        return x.view(B, *shape, -1)#.view(*shape, -1)
