import os
from PIL import Image
from io import BytesIO
import random
import numpy as np
import torch
from torch.utils.data import Dataset
from torchvision import transforms
from datasets.loadutils import FileClient
from datasets import register
import pillow_avif
import lmdb
import math
from sklearn.preprocessing import OneHotEncoder


def make_coord(shape, ranges=None, flatten=True):
    """
    Make coordinates at grid centers.
    """

    coord_seqs = []
    for i, n in enumerate(shape):
        if ranges is None:
            v0, v1 = -1, 1
        else:
            v0, v1 = ranges[i]
        r = (v1 - v0) / (2 * n)
        seq = v0 + r + (2 * r) * torch.arange(n).float()
        coord_seqs.append(seq)
    ret = torch.stack(torch.meshgrid(*coord_seqs), dim=-1)
    if flatten:
        ret = ret.view(-1, ret.shape[-1])
    return ret

def aligncrop(hr, lr, patch):
    _, H, W = hr.shape
    _, h, w = lr.shape
    rh = H/h
    rw = W/w
    h_lr_start = random.randint(0, h-patch)#0#
    w_lr_start = random.randint(0, w-patch)#0#
    lrcrop = lr[:, h_lr_start:h_lr_start+patch, w_lr_start:w_lr_start+patch]
    
    h_lr_start = h_lr_start*rh
    h_hr_start = math.ceil(h_lr_start)
    w_lr_start = w_lr_start*rw
    w_hr_start = math.ceil(w_lr_start)
    h_lr_end = h_lr_start+patch*rh
    h_hr_end = math.floor(h_lr_end)
    w_lr_end = w_lr_start+patch*rw
    w_hr_end = math.floor(w_lr_end)
    lrcrophr = hr[:, h_hr_start:h_hr_end, w_hr_start:w_hr_end]
    
    cropside = ((h_hr_start-h_lr_start,
                 h_lr_end - h_hr_end),
                 (w_hr_start-w_lr_start,
                 w_lr_end - w_hr_end))

    hr_coord_range = ((cropside[0][0]*2/(patch*rh)-1, 
                       1-cropside[0][1]*2/(patch*rh)), 
                      (cropside[1][0]*2/(patch*rw)-1, 
                       1-cropside[1][1]*2/(patch*rw)))
    hr_coord = make_coord(lrcrophr.shape[-2:], ranges=hr_coord_range, flatten=False)#True)
    
    return lrcrop, lrcrophr, hr_coord, rh, rw

def list_all_keys(lmdb_path):
    """
    列出LMDB数据库中的所有key。
    
    :param lmdb_path: LMDB数据库的文件路径。
    :return: key列表
    """
    # 打开LMDB环境
    env = lmdb.open(lmdb_path)
    keys = []

    # 遍历LMDB中的键值对，提取键
    with env.begin() as txn:
        cursor = txn.cursor()
        for key, _ in cursor:
            keys.append(key.decode('utf-8'))  # 解码key并添加到列表中

    env.close()
    return keys

def get_randn_int(start, end, notnum):
    while True:
        x = random.randint(start, end)
        if x!=notnum:
            break
    return x

@register('image-folder-lmdb-hronly')
class ImageFolderlmdbHr(Dataset):

    def __init__(self, path, repeat=1, scanfold=True):
        self.repeat = repeat
        self.lmdbpath = []
        self.imgpath = {}
        self.img = []
        self.file_client = None
        self.io_backend_opt = {}
        
        if scanfold:
            for dir in os.listdir(path):
                lmdb_path = os.path.join(os.path.join(path, dir))
                self.lmdbpath.append(lmdb_path)
        else:
            self.lmdbpath.append(path)
        
        for lmdb_path in self.lmdbpath:
            keys = list_all_keys(lmdb_path)
            print('get keys from{}'.format(lmdb_path))
            for key in keys:
                self.imgpath[key] = lmdb_path
                self.img.append(key)

        self.io_backend_opt['type'] = 'lmdb'
        self.io_backend_opt['db_paths'] = self.lmdbpath.copy()
        self.io_backend_opt['client_keys'] = self.lmdbpath.copy()

        self.max_retries = 10

    def __len__(self):
        return len(self.imgpath) * self.repeat

    def __getitem__(self, idx):
        key = self.img[idx % len(self.imgpath)]
        lmdb = self.imgpath[key]
        
        if self.file_client is None:
            self.file_client = FileClient(self.io_backend_opt.pop('type'), **self.io_backend_opt)
        
        for attempt in range(self.max_retries):
            try:
                img_bytes = self.file_client.get(key, lmdb)
                hr_image = Image.open(BytesIO(img_bytes))
            except Exception as e:
                print(f"Retry {attempt + 1}/{self.max_retries} for index {idx}: {e}")
                if attempt == self.max_retries - 1:
                    return self.__getitem__(get_randn_int(0, (self.__len__()-1), idx))

        hr_image = hr_image.convert('RGB')
        
        to_tensor_transform = transforms.ToTensor()
        hr_image = to_tensor_transform(hr_image)
        
        return hr_image

@register('image-folder-lmdb')
class ImageFolderlmdb(Dataset):

    def __init__(self, lr_path, gt_path, repeat=1, scanfold=True):
        self.repeat = repeat
        self.lr_lmdbpath = []
        self.lr_imgpath = {}
        self.lr_img = []
        self.file_client = None
        self.io_backend_opt = {}
        
        if scanfold:
            for dir in os.listdir(lr_path):
                lmdb_path = os.path.join(os.path.join(lr_path, dir))
                self.lr_lmdbpath.append(lmdb_path)
        else:
            self.lr_lmdbpath.append(lr_path)
        
        for lmdb_path in self.lr_lmdbpath:
            keys = list_all_keys(lmdb_path)
            print('get keys from{}'.format(lmdb_path))
            for key in keys:
                self.lr_imgpath[key] = lmdb_path
                self.lr_img.append(key)

        self.io_backend_opt['type'] = 'lmdb'
        self.io_backend_opt['db_paths'] = self.lr_lmdbpath.copy()
        self.io_backend_opt['client_keys'] = self.lr_lmdbpath.copy()
        
        self.io_backend_opt['db_paths'].append(gt_path)
        self.io_backend_opt['client_keys'].append('gt')

        self.max_retries = 20

    def __len__(self):
        return len(self.lr_imgpath) * self.repeat

    def __getitem__(self, idx):
        lr_key = self.lr_img[idx % len(self.lr_imgpath)]
        lr_lmdb = self.lr_imgpath[lr_key]
        hr_key = lr_key[:7]+'.png'
        
        if self.file_client is None:
            self.file_client = FileClient(self.io_backend_opt.pop('type'), **self.io_backend_opt)
        
        for attempt in range(self.max_retries):
            try:
                img_bytes = self.file_client.get(lr_key, lr_lmdb)
                lr_image = Image.open(BytesIO(img_bytes))
                img_bytes = self.file_client.get(hr_key, 'gt')
                hr_image = Image.open(BytesIO(img_bytes))
            except Exception as e:
                print(f"Retry {attempt + 1}/{self.max_retries} for index {idx}: {e}")
                if attempt == self.max_retries - 1:
                    return self.__getitem__(get_randn_int(0, (self.__len__()-1), idx))
                    # raise
        # img_bytes = self.file_client.get(lr_key, lr_lmdb)
        # lr_image = Image.open(BytesIO(img_bytes))
        # img_bytes = self.file_client.get(hr_key, 'gt')
        # hr_image = Image.open(BytesIO(img_bytes))

        lr_image = lr_image.convert('RGB') 
        hr_image = hr_image.convert('RGB')
        
        to_tensor_transform = transforms.ToTensor()
        lr_image = to_tensor_transform(lr_image)
        hr_image = to_tensor_transform(hr_image)
        
        return lr_image, hr_image, lr_key, hr_key

@register('sr-crop-paired')
class SRcropPaired(Dataset):

    def __init__(self, dataset, patch=None, augment=False, sample_q=None):
        self.dataset = dataset
        self.patch = patch
        self.augment = augment
        self.sample_q = sample_q

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, idx):
        img_lr, img_hr, lr_key, hr_key = self.dataset[idx]
        
        if self.patch:
            crop_lr, crop_hr, hr_coord, rh, rw = aligncrop(img_hr, img_lr, self.patch)
        else:
            crop_lr, crop_hr = img_lr, img_hr
            rh = crop_hr.shape[-2]/crop_lr.shape[-2]
            rw = crop_hr.shape[-1]/crop_lr.shape[-1]
            hr_coord = make_coord(crop_hr.shape[-2:], flatten=False)
        # assert rh == rw, 'no shape change please'
        assert hr_coord.dim()==3, 'hr_coord.dim()!=3'
        if self.augment:
            if random.random() < 0.5:
                crop_lr = crop_lr.flip(-2)
                crop_hr = crop_hr.flip(-2)
                hr_coord = hr_coord.flip(0)#coord的每一个信息点要与hr相对应
                hr_coord[:, :, 0] = hr_coord[:, :, 0]*(-1)#维度反转对coord对应维度影响
            if random.random() < 0.5:
                crop_lr = crop_lr.flip(-1)
                crop_hr = crop_hr.flip(-1)
                hr_coord = hr_coord.flip(1)
                hr_coord[:, :, 1] = hr_coord[:, :, 1]*(-1)
            if random.random() < 0.5:
                crop_lr = crop_lr.transpose(-2, -1)
                crop_hr = crop_hr.transpose(-2, -1)
                hr_coord = hr_coord.transpose(0, 1)
                hr_coord = hr_coord.flip(-1)

        crop_hr = crop_hr.contiguous().permute(1,2,0).contiguous().view(-1,3)
        hr_coord = hr_coord.contiguous().view(-1,2)
        if self.sample_q:
            sample_lst = np.random.choice(len(hr_coord), self.sample_q, replace=False)
            hr_coord = hr_coord[sample_lst]
            crop_hr = crop_hr[sample_lst]

        cell = torch.ones_like(hr_coord)
        cell[:, 0] *= 2 / (rh * crop_lr.shape[-2])
        cell[:, 1] *= 2 / (rw * crop_lr.shape[-1])

        return {
            'inp': crop_lr,
            'coord': hr_coord,
            'cell': cell,
            'gt': crop_hr,
            'lr_key': lr_key,
            'hr_key': hr_key
        }

@register('sr-crop-paired_encode')
class SRcropPairedencode(Dataset):

    def __init__(self, dataset, patch=None, augment=False, sample_q=None, onehot=True):
        self.dataset = dataset
        self.patch = patch
        self.augment = augment
        self.sample_q = sample_q
        self.onehot = onehot
        if self.onehot:
            self.names = ["avif", "webp", "jpeg", "avif_webp", "avif_jpeg", "webp_avif", "webp_jpeg", "jpeg_avif", "jpeg_webp"]
            self.encoder = OneHotEncoder(categories=[self.names])
            for i in self.names:
                self.encoder.fit([[i]])
        else:
            self.names = ["avif", "webp", "jpeg"]
            self.methoddict = dict(notin=0, avif=1, webp=2, jpeg=3)

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, idx):
        img_lr, img_hr, lr_key, hr_key = self.dataset[idx]
        
        if self.patch:
            crop_lr, crop_hr, hr_coord, rh, rw = aligncrop(img_hr, img_lr, self.patch)
        else:
            crop_lr, crop_hr = img_lr, img_hr
            rh = crop_hr.shape[-2]/crop_lr.shape[-2]
            rw = crop_hr.shape[-1]/crop_lr.shape[-1]
            hr_coord = make_coord(crop_hr.shape[-2:], flatten=False)
        # assert rh == rw, 'no shape change please'
        assert hr_coord.dim()==3, 'hr_coord.dim()!=3'
        if self.augment:
            if random.random() < 0.5:
                crop_lr = crop_lr.flip(-2)
                crop_hr = crop_hr.flip(-2)
                hr_coord = hr_coord.flip(0)#coord的每一个信息点要与hr相对应
                hr_coord[:, :, 0] = hr_coord[:, :, 0]*(-1)#维度反转对coord对应维度影响
            if random.random() < 0.5:
                crop_lr = crop_lr.flip(-1)
                crop_hr = crop_hr.flip(-1)
                hr_coord = hr_coord.flip(1)
                hr_coord[:, :, 1] = hr_coord[:, :, 1]*(-1)
            if random.random() < 0.5:
                crop_lr = crop_lr.transpose(-2, -1)
                crop_hr = crop_hr.transpose(-2, -1)
                hr_coord = hr_coord.transpose(0, 1)
                hr_coord = hr_coord.flip(-1)

        crop_hr = crop_hr.contiguous().permute(1,2,0).contiguous().view(-1,3)
        hr_coord = hr_coord.contiguous().view(-1,2)
        if self.sample_q:
            sample_lst = np.random.choice(len(hr_coord), self.sample_q, replace=False)
            hr_coord = hr_coord[sample_lst]
            crop_hr = crop_hr[sample_lst]

        cell = torch.ones_like(hr_coord)
        cell[:, 0] *= 2 / (rh * crop_lr.shape[-2])
        cell[:, 1] *= 2 / (rw * crop_lr.shape[-1])
        
        infocode = self.encoderdeg(lr_key)

        return {
            'inp': crop_lr,
            'coord': hr_coord,
            'cell': cell,
            'gt': crop_hr,
            'infocode': infocode,
            'lr_key': lr_key,
            'hr_key': hr_key
        }

    
    def encoderdeg(self, key):
        key = key.replace("crf", "qp").replace("_output","").replace("jpg", "jpeg")
        key, ext = os.path.splitext(key)
        keys = key.split('_')
        methods = []
        qps = []
        for k in keys:
            if k in self.names:
                methods.append([k])
            if "qp" in k:
                qps.append(float(k.replace("qp","")))
        if len(methods) == 0 :
            assert len(qps) == 1 , f" qp ({len(qps)}) and method not match"
            methods.append(["jpeg"])
        assert len(methods) == len(qps)," len(methods) != len(qps) "

        for i in range(len(methods)):
            if methods[i][0] == 'webp':
                qps[i] = (qps[i]-50)/(100-50)  # WebP uses a quality scale of 50-100
            elif methods[i][0] == 'jpeg':
                qps[i] = (qps[i]-10)/(31-10)   # JPEG uses a quality scale of 10-31
            elif methods[i][0] == 'avif':
                qps[i] = (qps[i]-10)/(63-10)   # AVIF uses a CRF scale of 10-63
        if len(qps) == 1 :
            qps.append(0)
        if self.onehot:
            if len(methods) == 2 :
                methods = [[methods[0][0]+"_"+methods[1][0]]]


            torch_qps = torch.tensor(qps).float().view(-1)
            assert methods[0][0] in self.names
            X_encoded = self.encoder.transform(methods).toarray()
            torch_method = torch.tensor(X_encoded).float().view(-1)

            return torch.cat([torch_method, torch_qps], dim = 0)
        else:
            if len(methods) == 1 :
                methods.append(['notin'])
            torch.qps = torch.tensor([int(self.methoddict[methods[0][0]]), qps[0], int(self.methoddict[methods[1][0]]), qps[1]]).float()
            return torch.qps
    
def save_tensor_as_image(tensor, save_path):
    print(tensor.shape)
    if tensor.ndimension() != 3 or tensor.size(0) != 3:
        raise ValueError("Expected a [C, H, W] tensor with 3 channels (RGB).")

    transform = transforms.ToPILImage()
    img = transform(tensor)

    img.save(save_path, format='PNG')
    print(f"Image saved to {save_path}")

