from .KAN import *
from .KAN_sample import *
from .KAN_notrain import *