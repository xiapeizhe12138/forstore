from .datasets import register, make
from . import image_folder
from . import wrappers
from . import wrappersdim2
