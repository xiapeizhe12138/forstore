import torch.nn as nn

from models import register
from pykan import kan

@register('kan')
class KAN(nn.Module):
    def __init__(self, width, indim=None, conv=False, convsize=1, grid=5, k=3, seed=0, **kwargs):
        super().__init__()
        if conv:
            assert indim is not None, "dim for kan not known"
            self.conv = nn.Conv2d(indim, width[1], convsize, padding=(convsize-1)//2, stride=1)
        else:
            self.conv = None
            if indim is not None:
                width[0] = indim

        self.kan = kan.KAN_sample(width=width, grid=grid, k=k, seed=seed, **kwargs)

    def forward(self, x):

        if self.conv:
            x = self.conv(x.permute(0, 3, 1, 2).contiguous()).permute(0, 2, 3, 1).contiguous()
        shape = x.shape[:-1]
        x = self.kan(x.view(-1, x.shape[-1]))
  
        return x.view(*shape, -1)
        
