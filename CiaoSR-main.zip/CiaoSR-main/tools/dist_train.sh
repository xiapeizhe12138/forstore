#!/usr/bin/env bash

# CONFIG=$1
# GPUS=$2
# PORT=$((12000 + $RANDOM % 20000))

# PYTHONPATH="$(dirname $0)/..":$PYTHONPATH \
# python -m torch.distributed.launch --nproc_per_node=$GPUS --master_port=$PORT \
    # "$(dirname "$0")"/train.py $CONFIG --launcher pytorch "${@:3}"

#python -m torch.distributed.launch --nproc_per_node=2 --master_port=4321 ./tools/train.py configs/001_localimplicitsr_rdn_div2k_g1_c64b16_1000k_unfold_lec_mulwkv_res_nonlocal.py --launcher pytorch
python -m torch.distributed.launch --nproc_per_node=8 --master_port=4321 debugpy --listen 5678 --wait-for-client ./tools/train.py configs/mglobal_ciaosr_rdn.py --launcher pytorch

pyd torch.distributed.launch --nproc_per_node=8 --master_port=4321 ./tools/train.py configs/mglobal_ciaosr_rdn.py --launcher pytorch

