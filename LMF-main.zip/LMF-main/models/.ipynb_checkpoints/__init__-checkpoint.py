from .models import register, make
from . import edsr, rdn, rcan, swinir
from . import mlp, lmmlp#, kan

from . import misc, liif, lte, ltep, ciaosr
from . import lmliif, lmlte, lmciaosr
# from . import ciaosr_forkan
# from . import ss2d, windowss2d
# from . import m3_middle_linear