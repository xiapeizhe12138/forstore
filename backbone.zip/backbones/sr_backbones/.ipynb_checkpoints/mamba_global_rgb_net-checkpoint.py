import torch
import torch.nn as nn
import torch.nn.functional as F
from mmcv.runner import load_checkpoint
from mmcv.cnn import constant_init
from mmedit.utils import get_root_logger
from mmedit.datasets.pipelines.utils import make_coord
from mmedit.models.builder import build_backbone, build_component
from mmedited.models.common.arch_csnln import CrossScaleAttention
from einops import repeat
import math
import numpy as np
import time
import pdb
from mmedited.models.backbones.sr_backbones.ss2d import SS2D

class SS2Dserial(nn.Module):
    def __init__(self,**kwargs):
        super().__init__()
        self.SS2D = SS2D(**kwargs)
    
    def forward(self, cord, input: torch.Tensor, outype='hwc',**kwargs):
        return [cord, self.SS2D(input, outype,**kwargs)]
        
class MgobalSRNetrgb(nn.Module):
    """
    The subclasses should define `generator` with `encoder` and `imnet`,
        and overwrite the function `gen_feature`.
    If `encoder` does not contain `mid_channels`, `__init__` should be
        overwrite.

    Args:
        encoder (dict): Config for the generator.
        imnet (dict): Config for the imnet.
        feat_unfold (bool): Whether to use feature unfold. Default: True.
        eval_bsize (int): Size of batched predict. Default: None.
    """

    def __init__(self,
                 encoder,
                 SSM,
                 cropstep=128,
                 mincrop=64,
                 local_size=2,
                 feat_unfold=True,
                 eval_bsize=None,
                 non_local_attn=True,
                 multi_scale=[2],
                 softmax_scale=1,
                 local_ensemble_out=False,
                 ):
        super().__init__()

        self.feat_unfold = feat_unfold
        self.eval_bsize = eval_bsize
        self.local_size = local_size
        self.non_local_attn = non_local_attn
        self.multi_scale = multi_scale
        self.softmax_scale = softmax_scale
        self.cropstep = cropstep
        self.mincrop = mincrop
        self.local_ensemble_out = local_ensemble_out

        # imnet
        self.encoder = build_backbone(encoder)
        if hasattr(self.encoder, 'mid_channels'):
            imnet_dim = self.encoder.mid_channels
        else:
            imnet_dim = self.encoder.embed_dim
        if self.feat_unfold:
            SSM['in_dim'] = imnet_dim * 9
        else:
            SSM['in_dim'] = imnet_dim
        
        if self.non_local_attn:
            SSM['in_dim'] += imnet_dim*len(multi_scale)

        SSM['in_dim'] += 4

        self.SS2Dr = SS2Dserial(d_model=SSM['in_dim'],
                    out_channel=SSM['out_channel'],
                    d_state=SSM['d_state'],
                    d_conv=SSM['d_conv'],
                    expand=SSM['expand']) 
        self.SS2Dg = SS2Dserial(d_model=SSM['in_dim'],
                    out_channel=SSM['out_channel'],
                    d_state=SSM['d_state'],
                    d_conv=SSM['d_conv'],
                    expand=SSM['expand']) 
        self.SS2Db = SS2Dserial(d_model=SSM['in_dim'],
                    out_channel=SSM['out_channel'],
                    d_state=SSM['d_state'],
                    d_conv=SSM['d_conv'],
                    expand=SSM['expand'])
        
        self.tail = nn.Conv2d(3*SSM['out_channel'], 3, 3, stride=1, padding=1)
        
        if self.non_local_attn:
            self.cs_attn = CrossScaleAttention(channel=imnet_dim, scale=multi_scale)    
            

    def forward(self, x, coord, cell, test_mode=False):
        """Forward function.

        Args:
            x: input tensor.
            coord (Tensor): coordinates tensor.
            cell (Tensor): cell tensor.
            test_mode (bool): Whether in test mode or not. Default: False.

        Returns:
            pred (Tensor): output of model.
        """
        # print(x.shape)
        # print(coord.shape)
        B, C, h, w = x.shape
        Bc, H, W, _ = coord.shape
        feature = self.gen_feature(x)

        if self.eval_bsize is None or not test_mode:
            pred = self.query_rgb(feature, coord, cell)
        else:
            pred = self.batched_predict(feature, coord, cell)

        pred += F.grid_sample(x, coord.view(Bc,H*W,-1).flip(-1).unsqueeze(1), mode='bilinear',\
                    padding_mode='border', align_corners=False)[:, :, 0, :].view(B,-1,H,W)#

        return pred


    def query_rgb(self, features, coord, scale=None):
        """Query RGB value of GT.

        Copyright (c) 2020, Yinbo Chen, under BSD 3-Clause License.

        Args:
            feature (Tensor): encoded feature.
            coord (Tensor): coord tensor, shape (BHW, 2).

        Returns:
            result (Tensor): (part of) output.
        """

        res = []
        # print(features[1])  error      features is just a tesor in dict  
        for feature in features:
            B, C, H, W = feature.shape      #[16, 64, 48, 48]
            bs, h, w, _ = coord.shape
            Br, Hr, Wr, Cr = scale.shape
            assert (h==Hr and w==Wr) , "size of coord and cell not match"

            if self.feat_unfold:
                if self.non_local_attn:
                    non_local_feat = self.cs_attn(feature)
                    feat = F.unfold(feature, 3, padding=1).view(B, C*9, H, W)
                    feat = torch.cat([feat, non_local_feat], dim=1)
                else:
                    feat = F.unfold(feature, 3, padding=1).view(B, C*9, H, W)
            else:
                feat = feature
                
            #low B, C, H, W
            #high B, C, h, w

            feat_coord = make_coord(feature.shape[-2:], flatten=False).permute(2, 0, 1) \
                            .unsqueeze(0).expand(B, 2, *feature.shape[-2:])                   #B,C,h,w
            feat_coord = feat_coord.to(coord)

            if self.local_size == 1:
                v_lst = [(0, 0)]
            else:
                v_lst = [(i,j) for i in range(-1, 2, 4-self.local_size) for j in range(-1, 2, 4-self.local_size)]
            eps_shift = 1e-6
            
            preds = []
            areas = []
            
            for v in v_lst:
                vx, vy = v[0], v[1]
                # project to LR field
                tx = ((H - 1) / (1 - scale[:,0,0,0])).view(B,  1)
                ty = ((W - 1) / (1 - scale[:,0,0,1])).view(B,  1)
                rx = (2*abs(vx) -1) / tx if vx != 0 else 0
                ry = (2*abs(vy) -1) / ty if vy != 0 else 0
                
                coord_ = coord.clone().view(bs, h*w, -1)
                if vx != 0:
                    coord_[:, :, 0] += vx /abs(vx) * rx + eps_shift
                if vy != 0:
                    coord_[:, :, 1] += vy /abs(vy) * ry + eps_shift
                coord_ = coord_.clamp_(-1 + 1e-6, 1 - 1e-6).view(bs, h, w, -1)
                
                # value
                upfeat = F.grid_sample(feat, coord_.flip(-1), mode='nearest',                 #upsize feature
                    align_corners=False).permute(0, 2, 3, 1).contiguous()                     #B,C,h,w

                #Interpolate feat_coord to HR resolution
                coord_k = F.grid_sample(feat_coord, coord_.flip(-1),                          #upsize feature coord
                    mode='nearest', align_corners=False).permute(0, 2, 3, 1).contiguous()     #B,C,h,w

                rel_coord = coord - coord_k                                                   #B,C,h,w
                rel_coord[:, :, :, 0] *= feature.shape[-2]                                    #relative coord information
                rel_coord[:, :, :, 1] *= feature.shape[-1]
                del coord_;del coord_k

                scale_ = scale.clone()                                                        #B,C,h,w
                scale_[:, :, :, 0] *= feature.shape[-2]                                       #size information
                scale_[:, :, :, 1] *= feature.shape[-1]

                inp = torch.cat([upfeat, rel_coord, scale_], dim=-1).contiguous()             #input get
                del upfeat;del scale_;

                predr = self.SS2Dr(cord = tx, input=inp, outype='chw')                                           #B,C,h,w
                predg = self.SS2Dg(cord = predr[0], input=inp, outype='chw')
                predb = self.SS2Db(cord = predg[0], input=inp, outype='chw')
                del inp
                
                pred = torch.cat([predr[1], predg[1], predb[1]], dim=1)
                del predr;del predg;del predb
                pred = self.tail(pred).permute(0, 2, 3, 1).contiguous()

                preds.append(pred)
                del pred

                area = torch.abs(rel_coord[:, :, :, 0] * rel_coord[:, :, :, 1])
                areas.append(area + 1e-9)
                del area

            tot_area = torch.stack(areas).sum(dim=0)
            if self.local_ensemble_out:
                t = areas[0]; areas[0] = areas[3]; areas[3] = t
                t = areas[1]; areas[1] = areas[2]; areas[2] = t
            ret = 0
            for pred, area in zip(preds, areas):#局部集成，计算多个参考的加权
                ret = ret + pred * (area / tot_area).unsqueeze(-1)
            res.append(ret)
    
        # print(ret.shape)
        # print(ret[1].shape)
        result = torch.cat(res, dim=-1).permute(0, 3, 1, 2).contiguous()                       #B,C,h,w
        # result = self.imnet_q(result, outype='chw')               # [16, 3, 48, 48]
        return result

    def cropdim(self, h):
        #我们希望将step转换成一个起始元素0，结束元素lenth/-1的递增序列，相邻元素之间间隔为crop，最末间隔不低于mincrop的数组
        step = np.arange(0, h, self.cropstep)
        if(h-step[-1] < self.mincrop):
            step[-1] = h
        else:
            step = np.append(step,h)
        return step
    
    def batched_predict(self, x, coord, cell):
        """Batched predict.

        Args:
            x (Tensor): Input tensor.
            coord (Tensor): coord tensor.
            cell (Tensor): cell tensor.

        Returns:
            pred (Tensor): output of model.
        """
        with torch.no_grad(): 
            B, C, h, w = x[0].shape 
            assert B==1, "batchsize not match"
            Bc, Hc, Wc, _ = coord.shape
            Br, Hr, Wr, _ = cell.shape
            H = round(float(2/cell[0,0,0,0]))
            W = round(float(2/cell[0,0,0,1]))
            assert H==Hc and H==Hr, "inputsize not match"
            assert W==Wc and W==Wr, "inputsize not match"
            # print(f"output.shape  {coord.shape}")
            hspace = self.cropdim(H)#, crop=120, mincrop=60)
            wspace = self.cropdim(W)#, crop=120, mincrop= 60)
            preds_hcrop = []
            for i in range(len(hspace)-1):
                preds_hwcrop = []
                for j in range(len(wspace)-1):
                    pred = self.query_rgb(x, coord[:, hspace[i]:hspace[i+1], wspace[j]:wspace[j+1], :].contiguous(),
                                      cell[:, hspace[i]:hspace[i+1], wspace[j]:wspace[j+1], :].contiguous())
                    preds_hwcrop.append(pred)
                pred = torch.cat(preds_hwcrop, dim=3)
                # print(f"preds_hcrop.shape  {pred.shape}")
                preds_hcrop.append(pred)
            pred = torch.cat(preds_hcrop, dim=2)
        return pred

    def init_weights(self, pretrained=None, strict=True):
        """Init weights for models.

        Args:
            pretrained (str, optional): Path for pretrained weights. If given
                None, pretrained weights will not be loaded. Defaults to None.
            strict (boo, optional): Whether strictly load the pretrained model.
                Defaults to True.
        """
        if isinstance(pretrained, str):
            logger = get_root_logger()
            load_checkpoint(self, pretrained, strict=strict, logger=logger)
        elif pretrained is not None:
            raise TypeError('"pretrained" must be a str or None. '
                            f'But received {type(pretrained)}.')


class MgobalImplicitSRRDNrgb(MgobalSRNetrgb):
    """ITSRN net based on RDN.

    Paper: Learning Continuous Image Representation with
           Local Implicit Image Function

    Args:
        encoder (dict): Config for the generator.
        imnet (dict): Config for the imnet.
        local_ensemble (bool): Whether to use local ensemble. Default: True.
        feat_unfold (bool): Whether to use feat unfold. Default: True.
        cell_decode (bool): Whether to use cell decode. Default: True.
        eval_bsize (int): Size of batched predict. Default: None.
    """

    def __init__(self,
                 encoder,
                 SSM,
                 cropstep=128,
                 mincrop=64,
                 local_size=2,
                 feat_unfold=True,
                 eval_bsize=None,
                 non_local_attn=True,
                 multi_scale=[2],
                 softmax_scale=1,
                 local_ensemble_out=False,
                 ):
        super().__init__(
            encoder=encoder,
            SSM=SSM,
            cropstep=cropstep,
            mincrop=mincrop,
            local_size=local_size,
            feat_unfold=feat_unfold,
            eval_bsize=eval_bsize,
            non_local_attn=non_local_attn,
            multi_scale=multi_scale,
            softmax_scale=softmax_scale,
            local_ensemble_out=local_ensemble_out,
            )

        self.sfe1 = self.encoder.sfe1
        self.sfe2 = self.encoder.sfe2
        self.rdbs = self.encoder.rdbs
        self.gff = self.encoder.gff
        self.num_blocks = self.encoder.num_blocks
        del self.encoder

    def gen_feature(self, x):
        """Generate feature.

        Args:
            x (Tensor): Input tensor with shape (n, c, h, w).

        Returns:
            Tensor: Forward results.
        """

        sfe1 = self.sfe1(x)
        sfe2 = self.sfe2(sfe1)

        x = sfe2
        local_features = []
        for i in range(self.num_blocks):
            x = self.rdbs[i](x)
            local_features.append(x)

        x = self.gff(torch.cat(local_features, 1)) + sfe1

        return [x]


