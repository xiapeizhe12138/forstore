import torch.nn as nn

from models import register
from collections import OrderedDict
import torch

import numpy as np
import torch.nn.functional as F
import torchvision.models as models

def sequential(*args):
    """Advanced nn.Sequential.

    Args:
        nn.Sequential, nn.Module

    Returns:
        nn.Sequential
    """
    if len(args) == 1:
        if isinstance(args[0], OrderedDict):
            raise NotImplementedError('sequential does not support OrderedDict input.')
        return args[0]  # No sequential is needed.
    modules = []
    for module in args:
        if isinstance(module, nn.Sequential):
            for submodule in module.children():
                modules.append(submodule)
        elif isinstance(module, nn.Module):
            modules.append(module)
    return nn.Sequential(*modules)

class ResBlock(nn.Module):
    def __init__(self, in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True):
        super(ResBlock, self).__init__()
        assert in_channels == out_channels, 'Only support in_channels==out_channels.'
        self.conv = sequential(
                        nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size, stride=stride, padding=padding, bias=bias),
                        nn.ReLU(inplace=True),
                        nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size, stride=stride, padding=padding, bias=bias))

    def forward(self, x):
        res = self.conv(x)
        return x + res

@register('pred_net')
class Pred_Net(nn.Module):
    def __init__(self, in_channels=64, out_channels=4, kernel_size=3):
        super().__init__()
        self.indim = in_channels
        self.qf_pred = sequential(# ResBlock(in_channels=in_channels, out_channels=in_channels, kernel_size=kernel_size),
                                  # nn.Conv2d(in_channels=in_channels, out_channels=128, kernel_size=kernel_size, padding=int(kernel_size/2), bias=True),
                                  # ResBlock(in_channels=128, out_channels=128, kernel_size=kernel_size),
                                  # nn.Conv2d(in_channels=128, out_channels=256, kernel_size=kernel_size, padding=int(kernel_size/2), bias=True),
                                  nn.Conv2d(in_channels=in_channels, out_channels=128, kernel_size=kernel_size, padding=int(kernel_size/2), bias=True),
                                  nn.ReLU(),
                                  nn.Conv2d(in_channels=128, out_channels=256, kernel_size=kernel_size, padding=int(kernel_size/2), bias=True),
                                  nn.AdaptiveAvgPool2d((1,1)),
                                  nn.Flatten(),
                                  nn.Linear(256, 512), 
                                  nn.ReLU(),
                                  nn.Linear(512, 512),
                                  nn.ReLU(),
                                  nn.Linear(512, out_channels),
                                  # nn.Sigmoid()
                                )

        
    def forward(self, x):
        B, C, H, W = x.shape
        assert C == self.indim, f"x.shape [B, C, H, W]: [{B}, {C}, {H}, {W}] must match as C == self.indim [{self.indim}]"
        x = self.qf_pred(x)
        
        return x
