import torch
import torch.nn as nn
import torch.nn.functional as F
from mmedited.models.backbones.sr_backbones.ss2d import SS2Dconcat

class windowss2d(nn.Module):
    def __init__(
            self,
            windowsize,
            d_model,
            out_channel = None,
            d_state=16,
            d_conv=3,
            expand=2.,
            batchsize=48,
            # **kwargs,
    ):
        super().__init__()
        self.ss2d = SS2Dconcat(d_model=d_model,
                        out_channel=out_channel,
                        d_state=d_state,
                        d_conv=d_conv,
                        expand=expand,
                         # **kwargs,
                        )
        self.inputchannel = d_model
        self.outchannel = out_channel
        self.windowsize = windowsize
        self.batchsize = batchsize
        
    def forward(self, input: torch.Tensor,**kwargs):
        #input B,C,H,W
        #OUTPUT B,H,W,C1
        B,C,H,W = input.shape
        assert H>self.windowsize and W>self.windowsize, "make sure input size > window size"
        assert C==self.inputchannel, "input channel does not match"

        pad = int((self.windowsize-1)/2)
        padding = (pad, pad, pad, pad)

        x=F.pad(input, padding, 'reflect')
        x = F.unfold(x, self.windowsize)

        x = x.view(B, C, self.windowsize, self.windowsize, H*W).permute(0,4,2,3,1).contiguous()
        x = x.view(B*H*W, self.windowsize, self.windowsize, C)
        L = B*H*W
        stepnum = int((L-(L%self.batchsize))/self.batchsize)
        output = []
        for i in range(stepnum):
            step = x[self.batchsize * i : self.batchsize*(i+1), :, :, :]
            # print(f"\n\nsize before SSM {step.shape}\n")
            step = self.ss2d(step).view(-1, self.windowsize*self.windowsize, self.outchannel)
            # print(f"\nsize before SSM {step.shape}\n\n")
            step = torch.mean(step, dim=1).view(-1, self.outchannel)
            output.append(step)
        if stepnum*self.batchsize != L:
            step = x[self.batchsize*stepnum:L, :, :, :]
            step = self.ss2d(step).view(-1, self.windowsize*self.windowsize, self.outchannel)
            step = torch.mean(step, dim=1).view(-1, self.outchannel)
            output.append(step)
        output = torch.cat(output, dim=0).view(B, H, W, self.outchannel).permute(0,3,1,2).contiguous()
        return output
        
        