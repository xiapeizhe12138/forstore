# -*- coding: utf-8 -*-
"""
Created on Wed Mar 27 21:53:18 2024

@author: 56486
"""
import torch
import math
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange, repeat
import numbers
from mamba_ssm.ops.selective_scan_interface import selective_scan_fn, selective_scan_ref
from ..models import register
########################################################################################################
################################## SS2D ################################################################



"""
d_model,输入的维度
out_channel = None, 当该值不为None时SSM后会接一个conv, 尺寸由d_conv指定, 并且决定输出维度
d_state=16,状态的维度
d_conv=3,自定义卷积
expand=2. channel扩大
dt_rank="auto",▲的维度
dt_min=0.001,
dt_max=0.1,
dt_init="random",
dt_scale=1.0,
dt_init_floor=1e-4,
dropout=0.,
conv_bias=True,
bias=False,
device=None,
dtype=None,
**kwargs,
"""

@register('ss2d')
class SS2D(nn.Module):
    def __init__(
            self,
            d_model,
            out_channel,
            d_state=16,
            d_conv=3,
            expand=2.,
            dt_rank="auto",
            dt_min=0.001,
            dt_max=0.1,
            dt_init="random",
            dt_scale=1.0,
            dt_init_floor=1e-4,
            dropout=0.,
            conv_bias=True,
            bias=False,
            device=None,
            dtype=None,
            **kwargs,
    ):
        factory_kwargs = {"device": device, "dtype": dtype}
        super().__init__()
        self.d_model = d_model
        self.d_state = d_state
        self.d_conv = d_conv
        self.expand = expand
        self.out_channel = out_channel
        self.d_inner = int(self.expand * self.d_model)
        self.dt_rank = math.ceil(self.d_model / 16) if dt_rank == "auto" else dt_rank
        self.in_proj = nn.Linear(self.d_model, self.d_inner * 2, bias=bias, **factory_kwargs)
        self.conv2d = nn.Conv2d(
            in_channels=self.d_inner,
            out_channels=self.d_inner,
            groups=self.d_inner,
            bias=conv_bias,
            kernel_size=d_conv,
            padding=(d_conv - 1) // 2,
            **factory_kwargs,
        )
        
        self.act = nn.SiLU()

        self.x_proj = (
            nn.Linear(self.d_inner, (self.dt_rank + self.d_state * 2), bias=False, **factory_kwargs),
            nn.Linear(self.d_inner, (self.dt_rank + self.d_state * 2), bias=False, **factory_kwargs),
            nn.Linear(self.d_inner, (self.dt_rank + self.d_state * 2), bias=False, **factory_kwargs),
            nn.Linear(self.d_inner, (self.dt_rank + self.d_state * 2), bias=False, **factory_kwargs),
        )
        self.x_proj_weight = nn.Parameter(torch.stack([t.weight for t in self.x_proj], dim=0))  # (K=4, N, inner)
        del self.x_proj

        self.dt_projs = (
            self.dt_init(self.dt_rank, self.d_inner, dt_scale, dt_init, dt_min, dt_max, dt_init_floor,
                         **factory_kwargs),
            self.dt_init(self.dt_rank, self.d_inner, dt_scale, dt_init, dt_min, dt_max, dt_init_floor,
                         **factory_kwargs),
            self.dt_init(self.dt_rank, self.d_inner, dt_scale, dt_init, dt_min, dt_max, dt_init_floor,
                         **factory_kwargs),
            self.dt_init(self.dt_rank, self.d_inner, dt_scale, dt_init, dt_min, dt_max, dt_init_floor,
                         **factory_kwargs),
        )
        self.dt_projs_weight = nn.Parameter(torch.stack([t.weight for t in self.dt_projs], dim=0))  # (K=4, inner, rank)
        self.dt_projs_bias = nn.Parameter(torch.stack([t.bias for t in self.dt_projs], dim=0))  # (K=4, inner)
        del self.dt_projs

        self.A_logs = self.A_log_init(self.d_state, self.d_inner, copies=4, merge=True)  # (K=4, D, N)
        self.Ds = self.D_init(self.d_inner, copies=4, merge=True)  # (K=4, D, N)

        self.selective_scan = selective_scan_fn

        self.in_norm = nn.LayerNorm(self.d_model)
        self.out_norm = nn.LayerNorm(self.d_inner)
        self.skipscale = nn.Conv2d(self.d_model, self.out_channel, bias=conv_bias,
                            kernel_size=1, padding=0, **factory_kwargs,)
        self.out_proj = nn.Linear(self.d_inner, self.out_channel, bias=bias, **factory_kwargs)
        self.dropout = nn.Dropout(dropout) if dropout > 0. else None

    @staticmethod
    def dt_init(dt_rank, d_inner, dt_scale=1.0, dt_init="random", dt_min=0.001, dt_max=0.1, dt_init_floor=1e-4,
                **factory_kwargs):
        dt_proj = nn.Linear(dt_rank, d_inner, bias=True, **factory_kwargs)

        # Initialize special dt projection to preserve variance at initialization
        dt_init_std = dt_rank ** -0.5 * dt_scale
        if dt_init == "constant":
            nn.init.constant_(dt_proj.weight, dt_init_std)
        elif dt_init == "random":
            nn.init.uniform_(dt_proj.weight, -dt_init_std, dt_init_std)
        else:
            raise NotImplementedError

        # Initialize dt bias so that F.softplus(dt_bias) is between dt_min and dt_max
        dt = torch.exp(
            torch.rand(d_inner, **factory_kwargs) * (math.log(dt_max) - math.log(dt_min))
            + math.log(dt_min)
        ).clamp(min=dt_init_floor)
        # Inverse of softplus: https://github.com/pytorch/pytorch/issues/72759
        inv_dt = dt + torch.log(-torch.expm1(-dt))
        with torch.no_grad():
            dt_proj.bias.copy_(inv_dt)
        # Our initialization would set all Linear.bias to zero, need to mark this one as _no_reinit
        dt_proj.bias._no_reinit = True

        return dt_proj

    @staticmethod
    def A_log_init(d_state, d_inner, copies=1, device=None, merge=True):
        # S4D real initialization
        A = repeat(
            torch.arange(1, d_state + 1, dtype=torch.float32, device=device),
            "n -> d n",
            d=d_inner,
        ).contiguous()
        A_log = torch.log(A)  # Keep A_log in fp32
        if copies > 1:
            A_log = repeat(A_log, "d n -> r d n", r=copies)
            if merge:
                A_log = A_log.flatten(0, 1)
        A_log = nn.Parameter(A_log)
        A_log._no_weight_decay = True
        return A_log

    @staticmethod
    def D_init(d_inner, copies=1, device=None, merge=True):
        # D "skip" parameter
        D = torch.ones(d_inner, device=device)
        if copies > 1:
            D = repeat(D, "n1 -> r n1", r=copies)
            if merge:
                D = D.flatten(0, 1)
        D = nn.Parameter(D)  # Keep in fp32
        D._no_weight_decay = True
        return D

    def forward_core(self, x: torch.Tensor):
        B, C, H, W = x.shape
        #此时的输入为[B,C*d_inner,H,W]，可以认为输入在上一步被扩充了channel
        L = H * W
        #L表示输入的长度，可以认为是token的长度
        K = 4
        #代表4种扫描方式
        x_hwwh = torch.stack([x.view(B, -1, L), torch.transpose(x, dim0=2, dim1=3).contiguous().view(B, -1, L)], dim=1).view(B, 2, -1, L)
        #将token平铺，同时转置HW平铺，然后二者Concat可以认为是为后面4种扫描方向的2种做数据准备
        xs = torch.cat([x_hwwh, torch.flip(x_hwwh, dims=[-1])], dim=1) # (1, 4, 192, 3136)
        #flip翻转后为另外两种扫描方式做数据数据准备
        x_dbl = torch.einsum("b k d l, k c d -> b k c l", xs.view(B, K, -1, L), self.x_proj_weight)
        #x_proj_weight是x_proj线性层对应的参数，shape为[4,N,inner]，N代表token长度
        #x_proj为将张量从d_inner投到dt_rank + d_state * 2，这是为了生成▲和B,C，
        #这步是为了构造可学习的矩阵，因为B,C,▲是通过输入进行全链接从而生成的。
        dts, Bs, Cs = torch.split(x_dbl, [self.dt_rank, self.d_state, self.d_state], dim=2)
        #拆分出dts,Bs,和Cs,这里的S表示S6可学习的ABC▲，此时▲的维度是1代表这一次输入的门控
        del x_dbl;del x_hwwh
        dts = torch.einsum("b k r l, k d r -> b k d l", dts.view(B, K, -1, L), self.dt_projs_weight)

        #0阶保持求出可学习的dts这时扩充了▲的维度表示多个channel的门控
        xs = xs.float().view(B, -1, L)
        #合并多条扫描线路concat
        dts = dts.contiguous().float().view(B, -1, L) # (b, k * d, l)
        Bs = Bs.float().view(B, K, -1, L)
        Cs = Cs.float().view(B, K, -1, L) # (b, k, d_state, l)
        Ds = self.Ds.float().view(-1)
        #维度调整
        As = -torch.exp(self.A_logs.float()).view(-1, self.d_state)
        dt_projs_bias = self.dt_projs_bias.float().view(-1) # (k * d)
        out_y = self.selective_scan(
            xs, dts,
            As, Bs, Cs, Ds, z=None,
            delta_bias=dt_projs_bias,
            delta_softplus=True,
            return_last_state=False,
        ).view(B, K, -1, L)
        del xs;del Bs;del Cs;del dts
        assert out_y.dtype == torch.float

        inv_y = torch.flip(out_y[:, 2:4], dims=[-1]).view(B, 2, -1, L)
        wh_y = torch.transpose((out_y[:, 1]).view(B, -1, W, H), dim0=2, dim1=3).contiguous()
        invwh_y = torch.transpose((inv_y[:, 1]).view(B, -1, W, H), dim0=2, dim1=3).contiguous()

        return (out_y[:, 0]).view(B, -1, H, W), (inv_y[:, 0]).view(B, -1, H, W), wh_y, invwh_y

    def forward(self, input: torch.Tensor, outype='hwc',**kwargs):
        x = self.in_norm(input)
        B, H, W, C = x.shape
        #C==d_model

        xz = self.in_proj(x)
        #expand表示维度扩展shortcut，d_Inner=d_model*expand
        #将输入[B,H,W,C]沿着channel括成[B,H,W,2*d_inner]
        x, z = xz.chunk(2, dim=-1)
        del xz
        #将xz拆分为2个[B,H,W,d_inner]
        x = x.permute(0, 3, 1, 2).contiguous()
        #将x改成[B,d_inner,H,W]便于进行conv
        x = self.act(self.conv2d(x))
        #组卷积，一组为d_inner个channel,对每组分别进行
        y1, y2, y3, y4 = self.forward_core(x)
        del x
        assert y1.dtype == torch.float32

        y = y1 + y2 + y3 + y4
        del y1;del y2;del y3;del y4
        y = y.permute(0, 2, 3, 1).contiguous()#B, H, W, C

        y = self.out_norm(y)
        y = y * self.act(z)
        del z
        
        skip = self.skipscale(input.permute(0, 3, 1, 2).contiguous()).permute(0, 2, 3, 1).contiguous()
        out = self.out_proj(y) + skip

        if self.dropout is not None:
            out = self.dropout(out)

        if outype=='chw':
            out = out.permute(0, 3, 1, 2).contiguous()
        return out


####################################################################################################################################################
####################################################################################################################################################

    
class SS2D2linear(nn.Module):
    def __init__(
            self,
            d_model,
            out_channel,
            d_state=16,
            d_conv=3,
            expand=2.,
            dt_rank="auto",
            dt_min=0.001,
            dt_max=0.1,
            dt_init="random",
            dt_scale=1.0,
            dt_init_floor=1e-4,
            dropout=0.,
            conv_bias=True,
            bias=False,
            device=None,
            dtype=None,
            **kwargs,
    ):
        factory_kwargs = {"device": device, "dtype": dtype}
        super().__init__()
        self.d_model = d_model
        self.d_state = d_state
        self.d_conv = d_conv
        self.expand = expand
        self.out_channel = out_channel
        self.d_inner = int(self.expand * self.d_model)
        self.dt_rank = math.ceil(self.d_model / 16) if dt_rank == "auto" else dt_rank
        self.in_proj = nn.Linear(self.d_model, self.d_inner * 2, bias=bias, **factory_kwargs)
        self.in2_proj = nn.Linear(self.d_inner, self.d_inner, bias=bias, **factory_kwargs)
        self.conv2d = nn.Conv2d(
            in_channels=self.d_inner,
            out_channels=self.d_inner,
            groups=self.d_inner,
            bias=conv_bias,
            kernel_size=d_conv,
            padding=(d_conv - 1) // 2,
            **factory_kwargs,
        )
        
        self.act = nn.SiLU()

        self.x_proj = (
            nn.Linear(self.d_inner, (self.dt_rank + self.d_state * 2), bias=False, **factory_kwargs),
            nn.Linear(self.d_inner, (self.dt_rank + self.d_state * 2), bias=False, **factory_kwargs),
            nn.Linear(self.d_inner, (self.dt_rank + self.d_state * 2), bias=False, **factory_kwargs),
            nn.Linear(self.d_inner, (self.dt_rank + self.d_state * 2), bias=False, **factory_kwargs),
        )
        self.x_proj_weight = nn.Parameter(torch.stack([t.weight for t in self.x_proj], dim=0))  # (K=4, N, inner)
        del self.x_proj

        self.dt_projs = (
            self.dt_init(self.dt_rank, self.d_inner, dt_scale, dt_init, dt_min, dt_max, dt_init_floor,
                         **factory_kwargs),
            self.dt_init(self.dt_rank, self.d_inner, dt_scale, dt_init, dt_min, dt_max, dt_init_floor,
                         **factory_kwargs),
            self.dt_init(self.dt_rank, self.d_inner, dt_scale, dt_init, dt_min, dt_max, dt_init_floor,
                         **factory_kwargs),
            self.dt_init(self.dt_rank, self.d_inner, dt_scale, dt_init, dt_min, dt_max, dt_init_floor,
                         **factory_kwargs),
        )
        self.dt_projs_weight = nn.Parameter(torch.stack([t.weight for t in self.dt_projs], dim=0))  # (K=4, inner, rank)
        self.dt_projs_bias = nn.Parameter(torch.stack([t.bias for t in self.dt_projs], dim=0))  # (K=4, inner)
        del self.dt_projs

        self.A_logs = self.A_log_init(self.d_state, self.d_inner, copies=4, merge=True)  # (K=4, D, N)
        self.Ds = self.D_init(self.d_inner, copies=4, merge=True)  # (K=4, D, N)

        self.selective_scan = selective_scan_fn

        self.in_norm = nn.LayerNorm(self.d_model)
        self.out_norm = nn.LayerNorm(self.d_inner)
        self.skipscale = nn.Conv2d(self.d_model, self.out_channel, bias=conv_bias,
                            kernel_size=1, padding=0, **factory_kwargs,)
        self.out_proj = nn.Linear(self.d_inner, self.out_channel, bias=bias, **factory_kwargs)
        self.dropout = nn.Dropout(dropout) if dropout > 0. else None

    @staticmethod
    def dt_init(dt_rank, d_inner, dt_scale=1.0, dt_init="random", dt_min=0.001, dt_max=0.1, dt_init_floor=1e-4,
                **factory_kwargs):
        dt_proj = nn.Linear(dt_rank, d_inner, bias=True, **factory_kwargs)

        # Initialize special dt projection to preserve variance at initialization
        dt_init_std = dt_rank ** -0.5 * dt_scale
        if dt_init == "constant":
            nn.init.constant_(dt_proj.weight, dt_init_std)
        elif dt_init == "random":
            nn.init.uniform_(dt_proj.weight, -dt_init_std, dt_init_std)
        else:
            raise NotImplementedError

        # Initialize dt bias so that F.softplus(dt_bias) is between dt_min and dt_max
        dt = torch.exp(
            torch.rand(d_inner, **factory_kwargs) * (math.log(dt_max) - math.log(dt_min))
            + math.log(dt_min)
        ).clamp(min=dt_init_floor)
        # Inverse of softplus: https://github.com/pytorch/pytorch/issues/72759
        inv_dt = dt + torch.log(-torch.expm1(-dt))
        with torch.no_grad():
            dt_proj.bias.copy_(inv_dt)
        # Our initialization would set all Linear.bias to zero, need to mark this one as _no_reinit
        dt_proj.bias._no_reinit = True

        return dt_proj

    @staticmethod
    def A_log_init(d_state, d_inner, copies=1, device=None, merge=True):
        # S4D real initialization
        A = repeat(
            torch.arange(1, d_state + 1, dtype=torch.float32, device=device),
            "n -> d n",
            d=d_inner,
        ).contiguous()
        A_log = torch.log(A)  # Keep A_log in fp32
        if copies > 1:
            A_log = repeat(A_log, "d n -> r d n", r=copies)
            if merge:
                A_log = A_log.flatten(0, 1)
        A_log = nn.Parameter(A_log)
        A_log._no_weight_decay = True
        return A_log

    @staticmethod
    def D_init(d_inner, copies=1, device=None, merge=True):
        # D "skip" parameter
        D = torch.ones(d_inner, device=device)
        if copies > 1:
            D = repeat(D, "n1 -> r n1", r=copies)
            if merge:
                D = D.flatten(0, 1)
        D = nn.Parameter(D)  # Keep in fp32
        D._no_weight_decay = True
        return D

    def forward_core(self, x: torch.Tensor):
        B, C, H, W = x.shape
        #此时的输入为[B,C*d_inner,H,W]，可以认为输入在上一步被扩充了channel
        L = H * W
        #L表示输入的长度，可以认为是token的长度
        K = 4
        #代表4种扫描方式
        x_hwwh = torch.stack([x.view(B, -1, L), torch.transpose(x, dim0=2, dim1=3).contiguous().view(B, -1, L)], dim=1).view(B, 2, -1, L)
        #将token平铺，同时转置HW平铺，然后二者Concat可以认为是为后面4种扫描方向的2种做数据准备
        xs = torch.cat([x_hwwh, torch.flip(x_hwwh, dims=[-1])], dim=1) # (1, 4, 192, 3136)
        #flip翻转后为另外两种扫描方式做数据数据准备
        x_dbl = torch.einsum("b k d l, k c d -> b k c l", xs.view(B, K, -1, L), self.x_proj_weight)
        #x_proj_weight是x_proj线性层对应的参数，shape为[4,N,inner]，N代表token长度
        #x_proj为将张量从d_inner投到dt_rank + d_state * 2，这是为了生成▲和B,C，
        #这步是为了构造可学习的矩阵，因为B,C,▲是通过输入进行全链接从而生成的。
        dts, Bs, Cs = torch.split(x_dbl, [self.dt_rank, self.d_state, self.d_state], dim=2)
        #拆分出dts,Bs,和Cs,这里的S表示S6可学习的ABC▲，此时▲的维度是1代表这一次输入的门控
        del x_dbl;del x_hwwh
        dts = torch.einsum("b k r l, k d r -> b k d l", dts.view(B, K, -1, L), self.dt_projs_weight)

        #0阶保持求出可学习的dts这时扩充了▲的维度表示多个channel的门控
        xs = xs.float().view(B, -1, L)
        #合并多条扫描线路concat
        dts = dts.contiguous().float().view(B, -1, L) # (b, k * d, l)
        Bs = Bs.float().view(B, K, -1, L)
        Cs = Cs.float().view(B, K, -1, L) # (b, k, d_state, l)
        Ds = self.Ds.float().view(-1)
        #维度调整
        As = -torch.exp(self.A_logs.float()).view(-1, self.d_state)
        dt_projs_bias = self.dt_projs_bias.float().view(-1) # (k * d)
        out_y = self.selective_scan(
            xs, dts,
            As, Bs, Cs, Ds, z=None,
            delta_bias=dt_projs_bias,
            delta_softplus=True,
            return_last_state=False,
        ).view(B, K, -1, L)
        del xs;del Bs;del Cs;del dts
        assert out_y.dtype == torch.float

        inv_y = torch.flip(out_y[:, 2:4], dims=[-1]).view(B, 2, -1, L)
        wh_y = torch.transpose((out_y[:, 1]).view(B, -1, W, H), dim0=2, dim1=3).contiguous()
        invwh_y = torch.transpose((inv_y[:, 1]).view(B, -1, W, H), dim0=2, dim1=3).contiguous()

        return (out_y[:, 0]).view(B, -1, H, W), (inv_y[:, 0]).view(B, -1, H, W), wh_y, invwh_y

    def forward(self, input: torch.Tensor, outype='hwc',**kwargs):
        x = self.in_norm(input)
        B, H, W, C = x.shape
        #C==d_model

        xz = self.in_proj(x)
        #expand表示维度扩展shortcut，d_Inner=d_model*expand
        #将输入[B,H,W,C]沿着channel括成[B,H,W,2*d_inner]
        x, z = xz.chunk(2, dim=-1)
        #将xz拆分为2个[B,H,W,d_inner]
        x = x.permute(0, 3, 1, 2).contiguous()
        #将x改成[B,d_inner,H,W]便于进行conv
        x = self.act(self.conv2d(x))
        #组卷积，一组为d_inner个channel,对每组分别进行
        y1, y2, y3, y4 = self.forward_core(x)
        assert y1.dtype == torch.float32

        y = y1 + y2 + y3 + y4
        del y1;del y2;del y3;del y4
        y = y.permute(0, 2, 3, 1).contiguous()#B, H, W, C

        y = self.out_norm(y)
        y = y * self.in2_proj(self.act(z))
        
        skip = self.skipscale(input.permute(0, 3, 1, 2).contiguous()).permute(0, 2, 3, 1).contiguous()
        out = self.out_proj(y) + skip

        if self.dropout is not None:
            out = self.dropout(out)

        if outype=='chw':
            out = out.permute(0, 3, 1, 2).contiguous()
        return out


####################################################################################################################################################
####################################################################################################################################################


class upSS2D(nn.Module):
    def __init__(
            self,
            d_model,
            out_channel = None,
            sizeadd=4,
            d_state=16,
            d_conv=3,
            expand=2.,
            dt_rank="auto",
            dt_min=0.001,
            dt_max=0.1,
            dt_init="random",
            dt_scale=1.0,
            dt_init_floor=1e-4,
            dropout=0.,
            conv_bias=True,
            bias=False,
            device=None,
            dtype=None,
            **kwargs,
    ):
        factory_kwargs = {"device": device, "dtype": dtype}
        super().__init__()
        self.d_model = d_model
        self.d_state = d_state
        self.sizeadd = sizeadd
        self.d_conv = d_conv
        self.expand = expand
        self.d_inner = int(self.expand * self.d_model)
        self.dt_rank = math.ceil(self.d_model / 16) if dt_rank == "auto" else dt_rank
        # self.conv_y = nn.Conv2d(4*self.d_inner, self.d_inner, 3, stride=1, padding=1)
        self.in_proj = nn.Linear(self.d_model, self.d_inner * 2, bias=bias, **factory_kwargs)
        self.conv2d = nn.Conv2d(
            in_channels=self.d_inner,
            out_channels=self.d_inner,
            groups=self.d_inner,
            bias=conv_bias,
            kernel_size=d_conv,
            padding=(d_conv - 1) // 2,
            **factory_kwargs,
        )
        
        self.out_channel = out_channel
        
        self.act = nn.SiLU()

        self.x_proj = (
            nn.Linear(self.d_inner, (self.dt_rank + self.d_state * 2), bias=False, **factory_kwargs),
            nn.Linear(self.d_inner, (self.dt_rank + self.d_state * 2), bias=False, **factory_kwargs),
            nn.Linear(self.d_inner, (self.dt_rank + self.d_state * 2), bias=False, **factory_kwargs),
            nn.Linear(self.d_inner, (self.dt_rank + self.d_state * 2), bias=False, **factory_kwargs),
        )
        self.x_proj_weight = nn.Parameter(torch.stack([t.weight for t in self.x_proj], dim=0))  # (K=4, N, inner)
        del self.x_proj

        self.dt_projs = (
            self.dt_init(self.dt_rank, self.d_inner, dt_scale, dt_init, dt_min, dt_max, dt_init_floor,
                         **factory_kwargs),
            self.dt_init(self.dt_rank, self.d_inner, dt_scale, dt_init, dt_min, dt_max, dt_init_floor,
                         **factory_kwargs),
            self.dt_init(self.dt_rank, self.d_inner, dt_scale, dt_init, dt_min, dt_max, dt_init_floor,
                         **factory_kwargs),
            self.dt_init(self.dt_rank, self.d_inner, dt_scale, dt_init, dt_min, dt_max, dt_init_floor,
                         **factory_kwargs),
        )
        self.dt_projs_weight = nn.Parameter(torch.stack([t.weight for t in self.dt_projs], dim=0))  # (K=4, inner, rank)
        self.dt_projs_bias = nn.Parameter(torch.stack([t.bias for t in self.dt_projs], dim=0))  # (K=4, inner)
        del self.dt_projs

        self.A_logs = self.A_log_init(self.d_state, self.d_inner, copies=4, merge=True)  # (K=4, D, N)
        self.Ds = self.D_init(self.d_inner, copies=4, merge=True)  # (K=4, D, N)

        self.selective_scan = selective_scan_fn
        if self.out_channel is not None:
            self.tail = nn.Conv2d(
                in_channels=self.d_model,
                out_channels=self.out_channel,
                bias=conv_bias,
                kernel_size=d_conv,
                padding=(d_conv - 1) // 2,
                **factory_kwargs,
            )
            
        self.in_norm = nn.LayerNorm(self.d_model - self.sizeadd)
        self.out_norm = nn.LayerNorm(self.d_inner)
        self.out_proj = nn.Linear(self.d_inner, self.d_model, bias=bias, **factory_kwargs)
        self.skipscale = nn.Conv2d(in_channels=self.d_model - self.sizeadd, out_channels=self.d_model, bias=conv_bias,
                            kernel_size=1, padding=0, **factory_kwargs,)
        self.dropout = nn.Dropout(dropout) if dropout > 0. else None

    @staticmethod
    def dt_init(dt_rank, d_inner, dt_scale=1.0, dt_init="random", dt_min=0.001, dt_max=0.1, dt_init_floor=1e-4,
                **factory_kwargs):
        dt_proj = nn.Linear(dt_rank, d_inner, bias=True, **factory_kwargs)

        # Initialize special dt projection to preserve variance at initialization
        dt_init_std = dt_rank ** -0.5 * dt_scale
        if dt_init == "constant":
            nn.init.constant_(dt_proj.weight, dt_init_std)
        elif dt_init == "random":
            nn.init.uniform_(dt_proj.weight, -dt_init_std, dt_init_std)
        else:
            raise NotImplementedError

        # Initialize dt bias so that F.softplus(dt_bias) is between dt_min and dt_max
        dt = torch.exp(
            torch.rand(d_inner, **factory_kwargs) * (math.log(dt_max) - math.log(dt_min))
            + math.log(dt_min)
        ).clamp(min=dt_init_floor)
        # Inverse of softplus: https://github.com/pytorch/pytorch/issues/72759
        inv_dt = dt + torch.log(-torch.expm1(-dt))
        with torch.no_grad():
            dt_proj.bias.copy_(inv_dt)
        # Our initialization would set all Linear.bias to zero, need to mark this one as _no_reinit
        dt_proj.bias._no_reinit = True

        return dt_proj

    @staticmethod
    def A_log_init(d_state, d_inner, copies=1, device=None, merge=True):
        # S4D real initialization
        A = repeat(
            torch.arange(1, d_state + 1, dtype=torch.float32, device=device),
            "n -> d n",
            d=d_inner,
        ).contiguous()
        A_log = torch.log(A)  # Keep A_log in fp32
        if copies > 1:
            A_log = repeat(A_log, "d n -> r d n", r=copies)
            if merge:
                A_log = A_log.flatten(0, 1)
        A_log = nn.Parameter(A_log)
        A_log._no_weight_decay = True
        return A_log

    @staticmethod
    def D_init(d_inner, copies=1, device=None, merge=True):
        # D "skip" parameter
        D = torch.ones(d_inner, device=device)
        if copies > 1:
            D = repeat(D, "n1 -> r n1", r=copies)
            if merge:
                D = D.flatten(0, 1)
        D = nn.Parameter(D)  # Keep in fp32
        D._no_weight_decay = True
        return D

    def forward_core(self, x: torch.Tensor):
        B, C, H, W = x.shape
        #此时的输入为[B,C*d_inner,H,W]，可以认为输入在上一步被扩充了channel
        L = H * W
        #L表示输入的长度，可以认为是token的长度
        K = 4
        #代表4种扫描方式
        x_hwwh = torch.stack([x.view(B, -1, L), torch.transpose(x, dim0=2, dim1=3).contiguous().view(B, -1, L)], dim=1).view(B, 2, -1, L)
        #将token平铺，同时转置HW平铺，然后二者Concat可以认为是为后面4种扫描方向的2种做数据准备
        xs = torch.cat([x_hwwh, torch.flip(x_hwwh, dims=[-1])], dim=1) # (1, 4, 192, 3136)
        #flip翻转后为另外两种扫描方式做数据数据准备
        # print(xs.shape)
        x_dbl = torch.einsum("b k d l, k c d -> b k c l", xs.view(B, K, -1, L), self.x_proj_weight)
        #x_proj_weight是x_proj线性层对应的参数，shape为[4,N,inner]，N代表token长度
        #x_proj为将张量从d_inner投到dt_rank + d_state * 2，这是为了生成▲和B,C，
        #这步是为了构造可学习的矩阵，因为B,C,▲是通过输入进行全链接从而生成的。
        # print(x_dbl.shape)
        # print(self.x_proj_weight.shape)
        dts, Bs, Cs = torch.split(x_dbl, [self.dt_rank, self.d_state, self.d_state], dim=2)
        #拆分出dts,Bs,和Cs,这里的S表示S6可学习的ABC▲，此时▲的维度是1代表这一次输入的门控
        # print(dts.shape,Bs.shape,Cs.shape)
        dts = torch.einsum("b k r l, k d r -> b k d l", dts.view(B, K, -1, L), self.dt_projs_weight)
        # print(self.dt_projs_weight.shape,dts.shape)
        # print(11111111111111111111111111111111111111)

        #0阶保持求出可学习的dts这时扩充了▲的维度表示多个channel的门控
        xs = xs.float().view(B, -1, L)
        # print(xs.shape)
        #合并多条扫描线路concat
        dts = dts.contiguous().float().view(B, -1, L) # (b, k * d, l)
        # print(dts.shape)
        Bs = Bs.float().view(B, K, -1, L)
        # print(f"B  {Bs.shape}")
        Cs = Cs.float().view(B, K, -1, L) # (b, k, d_state, l)
        # print(f"C  {Cs.shape}")
        Ds = self.Ds.float().view(-1)
        # print(Ds.shape)
        #维度调整
        As = -torch.exp(self.A_logs.float()).view(-1, self.d_state)
        # print(f"A  {As.shape}")
        dt_projs_bias = self.dt_projs_bias.float().view(-1) # (k * d)
        out_y = self.selective_scan(
            xs, dts,
            As, Bs, Cs, Ds, z=None,
            delta_bias=dt_projs_bias,
            delta_softplus=True,
            return_last_state=False,
        ).view(B, K, -1, L)
        assert out_y.dtype == torch.float
#        print(out_y.shape)
        inv_y = torch.flip(out_y[:, 2:4], dims=[-1]).view(B, 2, -1, L)
        # wh_y = torch.transpose(out_y[:, 1].view(B, -1, W, H), dim0=2, dim1=3).contiguous().view(B, -1, L)
        # invwh_y = torch.transpose(inv_y[:, 1].view(B, -1, W, H), dim0=2, dim1=3).contiguous().view(B, -1, L)
        wh_y = torch.transpose(out_y[:, 1].view(B, -1, W, H), dim0=2, dim1=3).contiguous()
        invwh_y = torch.transpose(inv_y[:, 1].view(B, -1, W, H), dim0=2, dim1=3).contiguous()

        return out_y[:, 0].view(B, -1, H, W), inv_y[:, 0].view(B, -1, H, W), wh_y, invwh_y

    def forward(self, input: torch.Tensor, addition=None, outype='hwc',**kwargs):
        x = self.in_norm(input)
        # B, H, W, C = x.shape
        B, H, W, Ca = addition.shape
        assert Ca == self.sizeadd , "addention shape not match"
        x = torch.cat((x,addition),dim=-1)
        #C==d_model
        xz = self.in_proj(x)
        #expand表示维度扩展shortcut，d_Inner=d_model*expand
        #将输入[B,H,W,C]沿着channel括成[B,H,W,2*d_inner]
        x, z = xz.chunk(2, dim=-1)
        # x, z = torch.split(xz, [self.d_inner - self.sizeadd, self.d_inner], dim=-1)
        #将xz拆分为2个[B,H,W,d_inner]
        x = x.permute(0, 3, 1, 2).contiguous()
        #将x改成[B,d_inner - sizeadd,H,W]便于进行conv
        x = self.act(self.conv2d(x))
        addition = addition.permute(0, 3, 1, 2).contiguous()
        
            
        #组卷积，一组为d_inner个channel,对每组分别进行
        y1, y2, y3, y4 = self.forward_core(x)
        assert y1.dtype == torch.float32

        y = y1 + y2 + y3 + y4
        y = y.permute(0, 2, 3, 1).contiguous()#B, H, W, C

        # print(f"y.shape {y.shape}")
        y = self.out_norm(y)
        y = y * self.act(z)
        
        skip = self.skipscale(input.permute(0, 3, 1, 2).contiguous()).permute(0, 2, 3, 1).contiguous()
        out = self.out_proj(y) + skip

        if self.dropout is not None:
            out = self.dropout(out)
        # print(f"out.shape {out.shape}")
        if self.out_channel is not None:
            out = self.act(out)
            if outype=='hwc':
                out = self.tail(out.permute(0, 3, 1, 2).contiguous()).permute(0, 2, 3, 1).contiguous()
            else:
                out = self.tail(out.permute(0, 3, 1, 2).contiguous())
        else:
            if outype!='hwc':
                out = out.permute(0, 3, 1, 2).contiguous()
        return out


####################################################################################################################################################
####################################################################################################################################################

if __name__=='__main__':
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print(device)

    channel = 13
    out = 3

    """SSM = SS2D(d_model=channel,
            out_channel = out,
            d_state=16,
            d_conv=3,
            expand=2.,
            dt_rank="auto",
            dt_min=0.001,
            dt_max=0.1,
            dt_init="random",
            dt_scale=1.0,
            dt_init_floor=1e-4,
            dropout=0.,
            conv_bias=True,
            bias=False,
            device=device,
            dtype=None).to(device)"""
    ss2d = SS2Dconcat(d_model=channel,
                        out_channel=out,
                        d_state=16,
                        d_conv=3,
                        expand=2.0,
                         # **kwargs,
                        ).to(device)
    
    x=torch.randn(3,5,7,channel).to(device)

    # print(SSM.d_model)
    # print(SSM.d_inner)
    # y = SSM.forward(x) 
    y = ss2d(x)
    """x = torch.tensor([[[[0.5, 0.5],
                       [0.5, 0],
                       [0, 0.5]],
                       [[1, 1],
                       [0, 1],
                       [1, 0]]]]).permute(0, 2, 3, 1)
    print(x.data)
    print(x.shape)
    ln = nn.LayerNorm(2)
    y = ln(x)"""

    # print(y)
    # print(y.data)
    print(y.shape)
#服务于人眼，手机，相机；服务于高层任务，注重鲁棒性
